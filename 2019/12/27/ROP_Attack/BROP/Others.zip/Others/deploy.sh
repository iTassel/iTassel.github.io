socat tcp-l:9999,reuseaddr,fork exec:./brop
