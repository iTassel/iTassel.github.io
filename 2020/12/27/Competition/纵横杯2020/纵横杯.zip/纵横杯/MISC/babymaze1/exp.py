#coding=utf-8
from pwn import*
import numpy as np
#context.log_level = 'DEBUG'
def Get_T(s):
	line = []
	tmp = []
	j = 0
	k = 0
	start = []
	end = []
	data = ''
	for i in range(s):
		data += p.recvline()
	data = data.replace('\x23','\x00')  # black 
	data = data.replace('\x20','\x01')  # white
	data = data.replace('\x24','\x03') # flag
	data = data.replace('\x2A','\x02')
	for i in data:
		if(i == '\n'):
			line.append(tmp)
			tmp = []
			j += 1
			k = 0
		elif(i == '\x02'):
			start.append(j)
			start.append(k)
			k += 1
			tmp.append(ord(i))
		elif(i == '\x03'):
			end.append(j)
			end.append(k)
			k += 1
			tmp.append(ord(i))
		else:
			k += 1
			tmp.append(ord(i))
	return line,start,end
###############################
def up(location):
    # 到达了数组顶端
    if location[0] == 0:
        return False
    else:
        new_location = [location[0] - 1, location[1]]
 
        # 走过的路不再走
        if new_location in history_path:
            return False
        # 遇到墙不走
        elif maze[new_location[0]][new_location[1]] == 0:
            return False
        else:
            lookup_path.append(new_location)
            history_path.append(new_location)
            return True
 
 
def down(location):
    # 遇到迷宫最下方的时候，不能继续往下走
    if location[0] == len(maze) - 1:
        return False
    else:
        new_location = [location[0] + 1, location[1]]
        # 走过的路不再走
        if new_location in history_path:
            return False
        # 遇到墙不走
        elif maze[new_location[0]][new_location[1]] == 0:
            return False
        else:
            history_path.append(new_location)
            lookup_path.append(new_location)
            return True
 
 
def left(location):
    # 遇到迷宫最左边，不能继续往左走
    if location[1] == 0:
        return False
    else:
        new_location = [location[0], location[1] - 1]
        # 走过的路不再走
        if new_location in history_path:
            return False
        # 遇到墙不走
        elif maze[new_location[0]][new_location[1]] == 0:
            return False
        else:
            history_path.append(new_location)
            lookup_path.append(new_location)
            return True
 
 
def right(location):
    # 遇到迷宫最右边，不能继续向右移动
    if location[1] == len(maze[0]) - 1:
        return False
    else:
        new_location = [location[0], location[1] + 1]
        # 走过的路不再走
        if new_location in history_path:
            return False
        # 遇到墙不走
        elif maze[new_location[0]][new_location[1]] == 0:
            return False
        else:
            history_path.append(new_location)
            lookup_path.append(new_location)
            return True
def get_line(path):
	p = ''
	for i in range(len(path)-1):
		tmp1 = path[i]
		tmp2 = path[i + 1]
		if tmp1[0] > tmp2[0]:
			p += 'w'
		elif tmp1[0] < tmp2[0]:
			p += 's'
		if tmp1[1] > tmp2[1]:
			p += 'a'
		elif tmp1[1] < tmp2[1]:
			p += 'd'
	return p
	

p = remote('182.92.203.154',11001)
p.sendlineafter('Please press any key to start.','FMYY')

for i in range(5):
	log.info('LEVEL' + str(i+1))
	maze,start,end = Get_T(11 + i*10)
	lookup_path = []
	history_path = []
	lookup_path.append(start)
	history_path.append(start)
	while lookup_path[-1] != end:
		now = lookup_path[-1]
		if up(now) or down(now) or left(now) or right(now):
			continue
		lookup_path.pop()
	#print("Final:", lookup_path)
	path = get_line(lookup_path)
	#log.info('PATH:\t' + path)
	p.sendlineafter('> ',path)
	p.recvuntil('your win\n')

p.interactive()

