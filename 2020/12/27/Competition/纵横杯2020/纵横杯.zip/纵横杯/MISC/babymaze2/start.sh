#!/bin/bash
python2.7 -u -c "import maze"


