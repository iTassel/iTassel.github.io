# coding=utf-8
from pwn import*
from Crypto.Util.number import *
import string
import hashlib
import random
s = '%p%p%pLC:%p'
def passwd():
	def F(code):
		hashresult=hashlib.sha256(s + code).digest().encode('hex').upper()
		return hashresult.startswith('E85000')

	prefix = util.iters.mbruteforce(F, string.ascii_letters + string.digits, 4, 'fixed')
	return prefix
print passwd()
