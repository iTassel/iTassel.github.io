from pwn import*
def menu(ch):
	p.sendlineafter('choice: ',str(ch))
def new(index,size):
	menu(1)
	p.sendlineafter('block ID:',str(index))
	p.sendlineafter('how big: ',str(size))
def free(index):
	menu(2)
	p.sendlineafter('throw?',str(index))
def edit(index,content):
	menu(3)
	p.sendlineafter('write?',str(index))
	p.sendafter('Content: ',content)
def des(content):
	menu(7)
	p.sendlineafter('feeling',content)
p = process('./main')
p.interactive()
