code = [10,24,119,7,104,43,28,91,108,52,88,74,88,33]
FLAG = ''
for i in range(12,-1,-1):
	code[i] = (code[i + 1] ^ code[i])&0xFF
for i in range(14):
	FLAG += chr(code[i])
print FLAG
