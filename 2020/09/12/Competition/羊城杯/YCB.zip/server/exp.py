from pwn import*
def C(content,cmd):
	p.sendafter('<<:',content + ' Connection: keep-alive ' + '\t\n' + cmd)
p = process('./main')
gdb.attach(p)
C('POST / index.html ','cmd=add ')
p.interactive()
