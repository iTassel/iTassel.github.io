package main

func main() {
	flag := []int64{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
	for i, v := range flag {
		flag[i] = v + 1
	}
	hack()
}


func hack() {
	
	rates := []uint64{0xFF,}
	for star ,rate := range rates{
		if star+1 < 1{
			panic("")
		}
		println(rate)
	}
}
