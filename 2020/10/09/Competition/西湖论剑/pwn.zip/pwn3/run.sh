./qemu-mipsel-static -L ./ ./managesystem
