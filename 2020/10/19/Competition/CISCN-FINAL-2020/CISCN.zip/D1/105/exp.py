from pwn import*
def menu(ch):
	p.sendlineafter('Exit',str(ch))
def new(size,content,start):
	menu(1)
	p.sendlineafter('length:',str(size))
	p.sendafter('code:',content)
	p.sendlineafter('address:',str(start))
	
def free(index):
	menu(2)
	p.sendlineafter('ID:',str(index))
def run(index):
	menu(3)
	p.sendlineafter('ID:',str(index))
p = process('./main')
new(0xF0,'0'*0xF0,'0')
gdb.attach(p,"b *$rebase(0x1B67)")
run(0)
p.interactive()
