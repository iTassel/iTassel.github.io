// gcc pass.c -o pass
int main()
{
	int i = 0;
	char buf[0x10] = {0x44,0,2,0x41,0x43,0x47,0x10,0x63,0x00};
	for ( i = 7; i >=0; --i )
   	    buf[i] = ~(~(buf[i] & buf[i + 1]) & (buf[i + 1] | buf[i]) & i) & (i | ~(buf[i] & buf[i + 1]) & (buf[i + 1] | buf[i]));
	printf("%s\n",buf);
}
